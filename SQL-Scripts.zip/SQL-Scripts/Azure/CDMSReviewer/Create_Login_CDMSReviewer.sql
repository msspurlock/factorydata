-- ======================================================================================
-- Create SQL Login template for Azure SQL Database and Azure SQL Data Warehouse Database
-- ======================================================================================

CREATE LOGIN CDMSReviewer 
	WITH PASSWORD = 'HQCan#0916@ViewOnly' 
GO
