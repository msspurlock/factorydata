-- ========================================================================================
-- Create User as DBO template for Azure SQL Database and Azure SQL Data Warehouse Database
-- ========================================================================================
-- For login CDMSReviewer, create a user in the database
CREATE USER CDMSReviewer
	FOR LOGIN CDMSReviewer
	WITH DEFAULT_SCHEMA = dbo
GO

-- Add user to the database owner role
EXEC sp_addrolemember N'db_datareader', N'CDMSReviewer'
GO

--GRANT VIEW DEFINITION ON Database::[Eligibility]   
--    TO CDMSReviewer WITH GRANT OPTION;  
--GO

--GRANT VIEW DEFINITION ON Database::[cdcn-eligibility-sql-dev]   
--    TO CDMSReviewer WITH GRANT OPTION;  
--GO

--GRANT VIEW DEFINITION ON Database::[PatientPay]   
--    TO CDMSReviewer WITH GRANT OPTION;  
--GO

--GRANT VIEW DEFINITION ON Database::[PatientPay_Copy]   
--    TO CDMSReviewer WITH GRANT OPTION;  
--GO
