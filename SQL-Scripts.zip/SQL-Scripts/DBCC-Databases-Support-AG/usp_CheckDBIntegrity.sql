USE [ISDB]
GO

/****** Object:  StoredProcedure [dbo].[usp_CheckDBIntegrity]    Script Date: 5/8/2019 8:55:44 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_CheckDBIntegrity]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_CheckDBIntegrity]
GO

/****** Object:  StoredProcedure [dbo].[usp_CheckDBIntegrity]    Script Date: 5/8/2019 8:55:44 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROC [dbo].[usp_CheckDBIntegrity] 

	@database_name     SYSNAME      = NULL
	,@no_email         BIT          = 1
	,@email_recipients VARCHAR(MAX) = ''

AS
BEGIN

	/*
	-- BRT - Rev 01 - 2019-05-08 - Modified to support servers with AG replicas and differences between AG in 2012 and 2016
	--                           - Also converted the get database names to dynamic SQL to prevent errors on pre-2016 servers
	--                           - that do not support distributed AG.
	*/
	SET NOCOUNT ON


	DECLARE @STATUS_ID_QUEUED TINYINT
	SET @STATUS_ID_QUEUED = 1
	DECLARE @STATUS_ID_PROCESSING TINYINT
	SET @STATUS_ID_PROCESSING = 2
	DECLARE @STATUS_ID_COMPLETED TINYINT
	SET @STATUS_ID_COMPLETED = 3
	DECLARE @STATUS_ID_ERROR TINYINT
	SET @STATUS_ID_ERROR = 4


	DECLARE @like_clause VARCHAR(500)

	SET @no_email         = COALESCE(@no_email, 0)
	SET @email_recipients = COALESCE(@email_recipients, '')

	IF @database_name IS NULL -- Run against all databases
	BEGIN
		
		-- BRT - Rev 01
		DECLARE @sql_server_major_version INT

		SELECT
			@sql_server_major_version = CONVERT(INT, SERVERPROPERTY('ProductMajorVersion'))
		-- BRT - Rev 01

		TRUNCATE TABLE dbcc_history;

		DECLARE @batch_id UNIQUEIDENTIFIER;

		SET @batch_id = NEWID();


		-- BRT - Rev 01
		DECLARE @get_databases_command NVARCHAR(4000)
		DECLARE @get_db_parameters     NVARCHAR(4000) = '@batch_id UNIQUEIDENTIFIER, @STATUS_ID_QUEUED TINYINT'
		
		IF @sql_server_major_version = 13 -- SQL 2016
		BEGIN

			SET @get_databases_command = 
			'
			SELECT
				[name] AS [database_name]
				,@batch_id
				,GETDATE()
				,@STATUS_ID_QUEUED
				,NULL
				,NULL
			FROM
			(
			SELECT 
				adc.[database_name] AS Name
			FROM 
				sys.availability_groups AS ag 
			INNER JOIN 
				sys.dm_hadr_availability_replica_states AS ars 
			ON 
				ars.group_id = ag.group_id
			INNER JOIN 
				sys.availability_databases_cluster AS adc 
			ON 
				adc.group_id = ag.group_id
			WHERE 
				ars.is_local = 1
				AND ars.role_desc = ''PRIMARY''
				AND NOT EXISTS 
				(
					SELECT 
						1
					FROM 
						sys.availability_groups AS dag 
					INNER JOIN 
						sys.availability_replicas AS fwd 
					ON 
						fwd.group_id = dag.group_id
					INNER JOIN 
						sys.availability_groups AS ag2 
					ON 
						ag2.name = fwd.replica_server_name
					INNER JOIN 
						sys.availability_databases_cluster AS db 
					ON 
						db.group_id = ag2.group_id
					WHERE 
						dag.is_distributed = 1
						AND db.[database_name] = adc.[database_name]
				)
			UNION ALL 
			SELECT 
				[name]
			FROM 
				sys.databases AS d
			WHERE 
				[is_read_only] = 0
				AND [state] = 0
				AND [source_database_id] IS NULL -- REAL DBS ONLY (Not Snapshots)
				AND [name] NOT LIKE ''%test%''
				AND [name] <> ''tempdb'' 
				AND NOT EXISTS 
				(
					SELECT 
						1 
					FROM 
						sys.availability_databases_cluster AS adc
					WHERE 
						adc.[database_name] = d.[name]
				)
			) AS dta
			ORDER BY 
				name;
			'
		END  -- IF @sql_server_major_version = 13 -- SQL 2016
		ELSE IF @sql_server_major_version = 11 OR @sql_server_major_version = 12 -- SQL 2012 OR 2014
		BEGIN

			SET @get_databases_command = 
			'
			SELECT
				[name] AS [database_name]
				,@batch_id
				,GETDATE()
				,@STATUS_ID_QUEUED
				,NULL
				,NULL
			FROM
			(
			SELECT 
				adc.[database_name] AS Name
			FROM 
				sys.availability_groups AS ag 
			INNER JOIN 
				sys.dm_hadr_availability_replica_states AS ars 
			ON 
				ars.group_id = ag.group_id
			INNER JOIN 
				sys.availability_databases_cluster AS adc 
			ON 
				adc.group_id = ag.group_id
			WHERE 
				ars.is_local = 1
				AND ars.role_desc = ''PRIMARY''
				-- REMOVED DISTRIBUTED AG TEST AS IT IS NOT COMPATIBLE WITH 2012
			UNION ALL 
			SELECT 
				[name]
			FROM 
				sys.databases AS d
			WHERE 
				[is_read_only] = 0
				AND [state] = 0
				AND [source_database_id] IS NULL -- REAL DBS ONLY (Not Snapshots)
				AND [name] NOT LIKE ''%test%''
				AND [name] <> ''tempdb'' 
				AND NOT EXISTS 
				(
					SELECT 
						1 
					FROM 
						sys.availability_databases_cluster AS adc
					WHERE 
						adc.[database_name] = d.[name]
				)
			) AS dta
			ORDER BY 
				name;
			'

		END  -- ELSE IF @sql_server_major_version = 11 OR @sql_server_major_version = 12 -- SQL 2012 OR 2014
		ELSE
		BEGIN

			-- OLD STANDBY
			SET @get_databases_command = 
			'
			SELECT
				[name] AS [database_name]
				,@batch_id
				,GETDATE()
				,@STATUS_ID_QUEUED
				,NULL
				,NULL
			FROM
				sys.databases db
			WHERE
				[name] NOT IN ( ''tempdb'' )
				AND db.state_desc = ''ONLINE''
				AND source_database_id IS NULL -- REAL DBS ONLY (Not Snapshots)
				AND is_read_only  = 0;
			'

		END  -- END ELSE 

		
		INSERT INTO
			ISDB.dbo.dbcc_executions
		(
			[database_name]
			,[batch_id]
			,[created_dt_tm]
			,[status]
			,[started_dt_tm]
			,[finished_dt_tm]
		)
		EXECUTE sp_executesql @get_databases_command, @get_db_parameters, @batch_id = @batch_id, @STATUS_ID_QUEUED = @STATUS_ID_QUEUED
		-- BRT - Rev 01



		DECLARE @previous_database_name SYSNAME

		SELECT TOP 1
			@database_name = e.[database_name]
		FROM
			ISDB.dbo.dbcc_executions AS e
		WHERE
			e.batch_id     = @batch_id
			AND e.[status] = @STATUS_ID_QUEUED
		ORDER BY
			e.[database_name] ASC


		WHILE @database_name IS NOT NULL
		BEGIN

			DECLARE @batch_sql   NVARCHAR(4000)
			DECLARE @parameters  NVARCHAR(4000)

			SET @parameters = '@vc_db_name SYSNAME, @batch_id UNIQUEIDENTIFIER'

			SET @batch_sql = N'EXEC ISDB.dbo.usp_DBCCCheckDB @vc_db_name, @batch_id'

			BEGIN TRY

				EXEC sys.sp_executesql @batch_sql, @parameters, @vc_db_name = @database_name, @batch_id = @batch_id

			END TRY
			BEGIN CATCH
				SET @batch_sql = ''
			END CATCH

			SET @previous_database_name = @database_name
			SET @database_name          = NULL

			SELECT TOP 1
				@database_name = e.[database_name]
			FROM
				ISDB.dbo.dbcc_executions AS e
			WHERE
				e.batch_id            = @batch_id
				AND e.[status]        = @STATUS_ID_QUEUED
				AND e.[database_name] > @previous_database_name
			ORDER BY
				e.[database_name] ASC

		END;  -- end while no database selected

	END;  -- end while batch mode
	ELSE -- run against a specified database (ie: usp_CheckDBIntegrity 'DB Name Here'
	BEGIN

		DECLARE @command_sql NVARCHAR(4000)
		SET @command_sql = N'DBCC CHECKDB(''' + @database_name + ''') WITH TABLERESULTS'

		SET @like_clause = '%CHECKDB %' + @database_name + '%'
		DELETE FROM ISDB.dbo.dbcc_history WHERE MessageText LIKE @like_clause

		INSERT INTO 
			dbo.dbcc_history
		(
			[Error],
			[Level],
			[State],
			[MessageText],
			[RepairLevel],
			[Status],
			[DbId],
			[DbFragId],
			[ObjectId],
			[IndexId],
			[PartitionID],
			[AllocUnitID],
			[RidDbId],
			[RidPruId],
			[File],
			[Page],
			[Slot],
			[RefDbId],
			[RefPruId],
			[RefFile],
			[RefPage],
			[RefSlot],
			[Allocation]
		)
		EXEC sys.sp_executesql @command_sql;

	END


	IF @no_email = 0
	BEGIN

		DECLARE @dbcc_history_data TABLE
		(
			[database_name]      SYSNAME      NOT NULL,
			[allocation_errors]  INT          NOT NULL,
			[consistency_errors] INT          NOT NULL,
			[message_text]       VARCHAR(MAX) NOT NULL,
			[timestamp]          DATETIME     NOT NULL
		)

		INSERT INTO
			@dbcc_history_data
		(
			[database_name],
			[allocation_errors],
			[consistency_errors],
			[message_text],
			[timestamp]
		)
		SELECT
			COALESCE(db.[name], cd.[db_name], '') AS [database_name],
			COALESCE(SUBSTRING(cd.allocation_errors, 0, PATINDEX('%[^0-9]%', cd.allocation_errors)), '') AS [allocation_errors],
			COALESCE(SUBSTRING(cd.consistency_errors, 0, PATINDEX('%[^0-9]%', cd.consistency_errors)), '') AS [consistency_errors],
			COALESCE(cd.MessageText, 'DBCC RESULTS NOT FOUND') AS [message_text],
			COALESCE(CONVERT(VARCHAR(25), cd.[TimeStamp]), '') AS [timestamp]
		FROM
		(
		SELECT
			REPLACE(REPLACE(REPLACE(SUBSTRING(dh.MessageText, PATINDEX('% database %', dh.MessageText), 999), ' database ', ''), '''', ''), '.', '') AS [db_name],
			LTRIM(RTRIM(REPLACE(SUBSTRING(dh.MessageText, PATINDEX('% found % allocation errors %', dh.MessageText), PATINDEX('% allocation errors %', dh.MessageText)), ' found ', ''))) AS [allocation_errors],
			LTRIM(RTRIM(REPLACE(SUBSTRING(dh.MessageText, PATINDEX('% and % consistency errors %', dh.MessageText), PATINDEX('% consistency errors %', dh.MessageText) - PATINDEX('% allocation errors %', dh.MessageText)), ' and ', ''))) AS [consistency_errors],
			dh.MessageText,
			dh.[TimeStamp]
		FROM
			ISDB.dbo.dbcc_history AS dh
		WHERE
			dh.MessageText LIKE 'CHECKDB %'
		) AS cd
		LEFT OUTER JOIN
			sys.databases AS db WITH (NOLOCK)
		ON
			cd.[db_name] = db.[name]


		DECLARE @summary_xml XML

		SELECT
			@summary_xml = 
			(
				SELECT
					*
				FROM
				(
					SELECT
						'header' AS "td1/@class",
						'Server Name' AS "td1",
						'header' AS "td2/@class",
						'Database{*LB*}Count' AS "td2",
						'header' AS "td3/@class",
						'CheckDB{*LB*}Count' AS "td3",
						'header' AS "td4/@class",
						'Total{*LB*}Allocation{*LB*}Errors' AS "td4",
						'header' AS "td5/@class",
						'Total{*LB*}Consistency{*LB*}Errors' AS "td5",
						'header' AS "td6/@class",
						'Time Stamp' AS "td6"

					UNION ALL

					SELECT
						'odd_row' AS "td1/@class",
						@@SERVERNAME AS "td1",
						'odd_row' AS "td2/@class",
						CONVERT(VARCHAR(25), COUNT(*)) AS "td2",
						'odd_row' AS "td3/@class",
						CONVERT(VARCHAR(25), 
						SUM(CASE
						WHEN message_text LIKE '%CHECKDB%' THEN 1
						ELSE 0
						END)) AS "td3",
						'odd_row' AS "td4/@class",
						CONVERT(VARCHAR(25), SUM(allocation_errors)) AS "td4",
						'odd_row' AS "td5/@class",
						CONVERT(VARCHAR(25), SUM(consistency_errors)) AS "td5",
						'odd_row' AS "td6/@class",
						CONVERT(VARCHAR(25), MAX(timestamp)) AS "td6"
					FROM
						@dbcc_history_data
				) AS table_data
				FOR XML PATH('tr'), ELEMENTS, ROOT('table')
			)


		DECLARE @report_xml XML

		SELECT
			@report_xml = 
			(
				SELECT
					*
				FROM
				(
					SELECT
						'header' AS "td1/@class",
						'Database Name' AS "td1",
						'header' AS "td2/@class",
						'Allocation{*LB*}Errors' AS "td2",
						'header' AS "td3/@class",
						'Consistency{*LB*}Errors' AS "td3",
						'header' AS "td4/@class",
						'Message Text' AS "td4",
						'header' AS "td5/@class",
						'Time Stamp' AS "td5"

					UNION ALL

					SELECT
						CASE WHEN is_odd = 1 THEN 'odd_row' ELSE 'even_row' END AS "td1/@class",
						td1 AS "td1",
						CASE WHEN is_odd = 1 THEN 'odd_row' ELSE 'even_row' END AS "td2/@class",
						td2 AS "td2",
						CASE WHEN is_odd = 1 THEN 'odd_row' ELSE 'even_row' END AS "td3/@class",
						td3 AS "td3",
						CASE WHEN is_odd = 1 THEN 'odd_row' ELSE 'even_row' END AS "td4/@class",
						td4 AS "td4",
						CASE WHEN is_odd = 1 THEN 'odd_row' ELSE 'even_row' END AS "td5/@class",
						td5 AS "td5"
					FROM
					(
						SELECT
							td1,
							CONVERT(VARCHAR(25), td2) AS td2,
							CONVERT(VARCHAR(25), td3) AS td3,
							td4,
							CONVERT(VARCHAR(25), td5) AS td5,
							(ROW_NUMBER() OVER (ORDER BY tr.td2 DESC, tr.td3 DESC, tr.td1 ASC) % 2) AS is_odd
						FROM
						(
							SELECT
								[database_name]      AS td1,
								[allocation_errors]  AS td2,
								[consistency_errors] AS td3,
								[message_text]       AS td4,
								[timestamp]          AS td5
							FROM
								@dbcc_history_data
						) AS tr
					) AS dta
				) AS table_data
				ORDER BY
					td2 DESC,
					td3 DESC,
					td1 ASC
				FOR XML PATH('tr'), ELEMENTS, ROOT('table')
			)


		DECLARE @summary_html VARCHAR(MAX)
		SELECT @summary_html = CONVERT(VARCHAR(MAX), @summary_xml);
		SELECT @summary_html = REPLACE(@summary_html, '<table>', '<table border="1" cellpadding="5" cellspacing="0">');
		SELECT @summary_html = REPLACE(@summary_html, 'td1', 'td');
		SELECT @summary_html = REPLACE(@summary_html, 'td2', 'td');
		SELECT @summary_html = REPLACE(@summary_html, 'td3', 'td');
		SELECT @summary_html = REPLACE(@summary_html, 'td4', 'td');
		SELECT @summary_html = REPLACE(@summary_html, 'td5', 'td');
		SELECT @summary_html = REPLACE(@summary_html, 'td6', 'td');
		SELECT @summary_html = REPLACE(@summary_html, '{*LB*}', '<br />');
		SELECT @summary_html = '<table border="0" cellpadding="5" cellspacing="0"><tr><td class="header">DBCC Results - Executive Summary:</td></tr><tr><td class="header">' + @summary_html + '</td></tr></table>';
		SELECT @summary_html = '<style>body{color:#12240f;font:arial;font-size:9pt;}.header{background-color:#74c167;font-weight:bold;vertical-align:bottom;}.odd_row{background-color:#eff8ed;}.even_row{background-color:#addaa4;}</style>' + @summary_html


		DECLARE @report_html VARCHAR(MAX)
		SELECT @report_html = CONVERT(VARCHAR(MAX), @report_xml)
		SELECT @report_html = REPLACE(@report_html, '<table>', '<table border="1" cellpadding="5" cellspacing="0">');
		SELECT @report_html = REPLACE(@report_html, 'td1', 'td');
		SELECT @report_html = REPLACE(@report_html, 'td2', 'td');
		SELECT @report_html = REPLACE(@report_html, 'td3', 'td');
		SELECT @report_html = REPLACE(@report_html, 'td4', 'td');
		SELECT @report_html = REPLACE(@report_html, 'td5', 'td');
		SELECT @report_html = REPLACE(@report_html, 'td6', 'td');
		SELECT @report_html = REPLACE(@report_html, '{*LB*}', '<br />');
		SELECT @report_html = '<table border="0" cellpadding="5" cellspacing="0"><tr><td class="header">DBCC Results: ' + @@SERVERNAME + '</td></tr><tr><td class="header">' + @report_html + '</td></tr></table>';
		--SELECT @report_html = '<style>body{color:#12240f;font:arial;font-size:9pt;}div{clear:both;}.header{background-color:#74c167;font-weight:bold;vertical-align:bottom;}.odd_row{background-color:#eff8ed;}.even_row{background-color:#addaa4;}</style>' + @report_html

		SELECT @report_html = @summary_html + '<br /><br />' + @report_html

		DECLARE @subject VARCHAR(100)

		SET @subject = ('DBCC Results: ' + @@SERVERNAME)

		IF COALESCE(@email_recipients, '') = ''
		BEGIN
			SET @email_recipients = 'SQL_MGMT@consumerdirectcare.com'
		END

		EXEC msdb.dbo.sp_send_dbmail
							@profile_name = 'SQLMail',
							@recipients   = @email_recipients,
							@subject      = @subject,
							@body         = @report_html,
							@body_format  = 'HTML'

	END  -- END IF @no_email = 0

	SET NOCOUNT OFF

END
GO


