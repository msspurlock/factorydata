USE [ISDB]
GO

/****** Object:  Table [dbo].[dbcc_executions]    Script Date: 5/8/2019 1:11:18 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbcc_executions]') AND type in (N'U'))
DROP TABLE [dbo].[dbcc_executions]
GO

/****** Object:  Table [dbo].[dbcc_executions]    Script Date: 5/8/2019 1:11:18 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[dbcc_executions](
	[database_name] [nvarchar](128) NOT NULL,
	[batch_id] [uniqueidentifier] NOT NULL,
	[created_dt_tm] [datetime] NOT NULL,
	[status] [tinyint] NOT NULL,
	[started_dt_tm] [datetime] NULL,
	[finished_dt_tm] [datetime] NULL,
 CONSTRAINT [PK_dbcc_executions] PRIMARY KEY CLUSTERED 
(
	[database_name] ASC,
	[batch_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO


