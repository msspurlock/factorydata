USE [ISDB]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_dbcc_history_TimeStamp]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dbcc_history] DROP CONSTRAINT [DF_dbcc_history_TimeStamp]
END
GO

/****** Object:  Table [dbo].[dbcc_history]    Script Date: 5/8/2019 1:11:33 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbcc_history]') AND type in (N'U'))
DROP TABLE [dbo].[dbcc_history]
GO

/****** Object:  Table [dbo].[dbcc_history]    Script Date: 5/8/2019 1:11:33 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[dbcc_history](
	[Error] [int] NULL,
	[Level] [int] NULL,
	[State] [int] NULL,
	[MessageText] [varchar](7000) NULL,
	[RepairLevel] [int] NULL,
	[Status] [int] NULL,
	[DbId] [int] NULL,
	[DbFragId] [int] NULL,
	[ObjectId] [int] NULL,
	[IndexId] [int] NULL,
	[PartitionID] [int] NULL,
	[AllocUnitID] [int] NULL,
	[RidDbId] [int] NULL,
	[RidPruId] [int] NULL,
	[File] [int] NULL,
	[Page] [int] NULL,
	[Slot] [int] NULL,
	[RefDbId] [int] NULL,
	[RefPruId] [int] NULL,
	[RefFile] [int] NULL,
	[RefPage] [int] NULL,
	[RefSlot] [int] NULL,
	[Allocation] [int] NULL,
	[TimeStamp] [datetime] NULL
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[dbcc_history] ADD  CONSTRAINT [DF_dbcc_history_TimeStamp]  DEFAULT (getdate()) FOR [TimeStamp]
GO


