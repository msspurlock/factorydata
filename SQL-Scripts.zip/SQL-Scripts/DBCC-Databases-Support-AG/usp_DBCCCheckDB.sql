USE [ISDB]
GO

/****** Object:  StoredProcedure [dbo].[usp_DBCCCheckDB]    Script Date: 5/8/2019 8:58:12 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_DBCCCheckDB]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_DBCCCheckDB]
GO

/****** Object:  StoredProcedure [dbo].[usp_DBCCCheckDB]    Script Date: 5/8/2019 8:58:12 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROC [dbo].[usp_DBCCCheckDB] 

    @database_name     SYSNAME          = ''
    ,@batch_id         UNIQUEIDENTIFIER = NULL

AS
BEGIN

    SET NOCOUNT ON


    DECLARE @STATUS_ID_QUEUED TINYINT
    SET @STATUS_ID_QUEUED = 1
    DECLARE @STATUS_ID_PROCESSING TINYINT
    SET @STATUS_ID_PROCESSING = 2
    DECLARE @STATUS_ID_COMPLETED TINYINT
    SET @STATUS_ID_COMPLETED = 3
    DECLARE @STATUS_ID_ERROR TINYINT
    SET @STATUS_ID_ERROR = 4


    IF LTRIM(RTRIM(COALESCE(@database_name, ''))) = ''
    BEGIN
	   RETURN -1
    END

    DECLARE @error INT
    
    SET @error = 0

    IF @batch_id IS NOT NULL
    BEGIN

	   BEGIN TRY

		  UPDATE
			 ISDB.dbo.dbcc_executions
		  SET
			 [status]       = @STATUS_ID_PROCESSING
			 ,started_dt_tm = GETDATE()
		  WHERE
			 [database_name] = @database_name
			 AND batch_id    = @batch_id

	   END TRY
	   BEGIN CATCH
		  SET @error = 1
		  GOTO exit_point
	   END CATCH

    END

    BEGIN TRY

	   INSERT INTO ISDB.dbo.dbcc_history
	   ([Error],
	   [Level],
	   [State],
	   [MessageText],
	   [RepairLevel],
	   [Status],
	   [DbId],
	   [DbFragId],
	   [ObjectId],
	   [IndexId],
	   [PartitionID],
	   [AllocUnitID],
	   [RidDbId],
	   [RidPruId],
	   [File],
	   [Page],
	   [Slot],
	   [RefDbId],
	   [RefPruId],
	   [RefFile],
	   [RefPage],
	   [RefSlot],
	   [Allocation]
	   )
	   EXECUTE('DBCC CHECKDB(''' + @database_name + ''') WITH TABLERESULTS')

    END TRY
    BEGIN CATCH
	   SET @error = 1
	   GOTO exit_point
    END CATCH



exit_point:

    IF @batch_id IS NOT NULL
    BEGIN

	   BEGIN TRY

		  UPDATE
			 ISDB.dbo.dbcc_executions
		  SET
			 [status]        = CASE WHEN @error = 1 THEN @STATUS_ID_ERROR WHEN @error = 0 THEN @STATUS_ID_COMPLETED ELSE 255 END
			 ,finished_dt_tm = GETDATE()
		  WHERE
			 [database_name] = @database_name
			 AND batch_id    = @batch_id

	   END TRY
	   BEGIN CATCH
		  SET @error = 2
	   END CATCH

    END

    SET NOCOUNT OFF

END
GO


