
	DECLARE @STATUS_ID_QUEUED TINYINT
	SET @STATUS_ID_QUEUED = 1
		
		-- BRT - Rev 01
		DECLARE @sql_server_major_version INT

		SELECT
			@sql_server_major_version = CONVERT(INT, SERVERPROPERTY('ProductMajorVersion'))
		-- BRT - Rev 01


		DECLARE @batch_id UNIQUEIDENTIFIER;

		SET @batch_id = NEWID();


		-- BRT - Rev 01
		DECLARE @get_databases_command NVARCHAR(4000)
		DECLARE @get_db_parameters     NVARCHAR(4000) = '@batch_id UNIQUEIDENTIFIER, @STATUS_ID_QUEUED TINYINT'
		
		IF @sql_server_major_version = 13 -- SQL 2016
		BEGIN

			SET @get_databases_command = 
			'
			SELECT
				[name] AS [database_name]
				,@batch_id
				,GETDATE()
				,@STATUS_ID_QUEUED
				,NULL
				,NULL
			FROM
			(
			SELECT 
				adc.[database_name] AS Name
			FROM 
				sys.availability_groups AS ag 
			INNER JOIN 
				sys.dm_hadr_availability_replica_states AS ars 
			ON 
				ars.group_id = ag.group_id
			INNER JOIN 
				sys.availability_databases_cluster AS adc 
			ON 
				adc.group_id = ag.group_id
			WHERE 
				ars.is_local = 1
				AND ars.role_desc = ''PRIMARY''
				AND NOT EXISTS 
				(
					SELECT 
						1
					FROM 
						sys.availability_groups AS dag 
					INNER JOIN 
						sys.availability_replicas AS fwd 
					ON 
						fwd.group_id = dag.group_id
					INNER JOIN 
						sys.availability_groups AS ag2 
					ON 
						ag2.name = fwd.replica_server_name
					INNER JOIN 
						sys.availability_databases_cluster AS db 
					ON 
						db.group_id = ag2.group_id
					WHERE 
						dag.is_distributed = 1
						AND db.[database_name] = adc.[database_name]
				)
			UNION ALL 
			SELECT 
				[name]
			FROM 
				sys.databases AS d
			WHERE 
				[is_read_only] = 0
				AND [state] = 0
				AND [source_database_id] IS NULL -- REAL DBS ONLY (Not Snapshots)
				AND [name] NOT LIKE ''%test%''
				AND [name] <> ''tempdb'' 
				AND NOT EXISTS 
				(
					SELECT 
						1 
					FROM 
						sys.availability_databases_cluster AS adc
					WHERE 
						adc.[database_name] = d.[name]
				)
			) AS dta
			ORDER BY 
				name;
			'
		END  -- IF @sql_server_major_version = 13 -- SQL 2016
		ELSE IF @sql_server_major_version = 11 OR @sql_server_major_version = 12 -- SQL 2012 OR 2014
		BEGIN

			SET @get_databases_command = 
			'
			SELECT
				[name] AS [database_name]
				,@batch_id
				,GETDATE()
				,@STATUS_ID_QUEUED
				,NULL
				,NULL
			FROM
			(
			SELECT 
				adc.[database_name] AS Name
			FROM 
				sys.availability_groups AS ag 
			INNER JOIN 
				sys.dm_hadr_availability_replica_states AS ars 
			ON 
				ars.group_id = ag.group_id
			INNER JOIN 
				sys.availability_databases_cluster AS adc 
			ON 
				adc.group_id = ag.group_id
			WHERE 
				ars.is_local = 1
				AND ars.role_desc = ''PRIMARY''
				-- REMOVED DISTRIBUTED AG TEST AS IT IS NOT COMPATIBLE WITH 2012
			UNION ALL 
			SELECT 
				[name]
			FROM 
				sys.databases AS d
			WHERE 
				[is_read_only] = 0
				AND [state] = 0
				AND [source_database_id] IS NULL -- REAL DBS ONLY (Not Snapshots)
				AND [name] NOT LIKE ''%test%''
				AND [name] <> ''tempdb'' 
				AND NOT EXISTS 
				(
					SELECT 
						1 
					FROM 
						sys.availability_databases_cluster AS adc
					WHERE 
						adc.[database_name] = d.[name]
				)
			) AS dta
			ORDER BY 
				name;
			'

		END  -- ELSE IF @sql_server_major_version = 11 OR @sql_server_major_version = 12 -- SQL 2012 OR 2014
		ELSE
		BEGIN

			-- OLD STANDBY
			SET @get_databases_command = 
			'
			SELECT
				[name] AS [database_name]
				,@batch_id
				,GETDATE()
				,@STATUS_ID_QUEUED
				,NULL
				,NULL
			FROM
				sys.databases db
			WHERE
				[name] NOT IN ( ''tempdb'' )
				AND db.state_desc = ''ONLINE''
				AND source_database_id IS NULL -- REAL DBS ONLY (Not Snapshots)
				AND is_read_only  = 0;
			'

		END  -- END ELSE 

		
		EXECUTE sp_executesql @get_databases_command, @get_db_parameters, @batch_id = @batch_id, @STATUS_ID_QUEUED = @STATUS_ID_QUEUED
		-- BRT - Rev 01
