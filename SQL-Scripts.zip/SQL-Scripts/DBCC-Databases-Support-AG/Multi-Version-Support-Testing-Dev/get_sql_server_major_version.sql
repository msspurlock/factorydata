SELECT CONVERT(INT, SERVERPROPERTY('ProductMajorVersion')) AS [ProductMajorVersion]

