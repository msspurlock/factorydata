

SELECT
	o.[name] AS object_name,
	c.[name] AS column_name
FROM
	sys.syscolumns AS c
INNER JOIN
	sys.objects AS o
ON
	o.object_id = c.id
	AND o.type = 'U'
WHERE
	c.[name] like '%emp%id%'


