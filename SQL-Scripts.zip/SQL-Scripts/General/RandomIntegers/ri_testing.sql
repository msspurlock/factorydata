DECLARE @in_digits    TINYINT = 9
DECLARE @in_min_value INT = 1
DECLARE @in_max_value INT = (SELECT COUNT(DISTINCT LTRIM(RTRIM(NameFirst))) FROM bridge.dbo.vwSLCustomer)

DECLARE @seed       INT = DATEPART(NANOSECOND, GETDATE())
DECLARE @multiplier INT = POWER(10, @in_digits)

SELECT
    CASE 
        WHEN @in_min_value > 0 AND @in_max_value > 0 THEN (CONVERT(INT, CONVERT(DECIMAL(18,12), RAND(@seed)) * @multiplier) % @in_max_value) + @in_min_value
        WHEN @in_min_value = 0 AND @in_max_value > 0 THEN (CONVERT(INT, CONVERT(DECIMAL(18,12), RAND(@seed)) * @multiplier) % @in_max_value)
        ELSE CONVERT(INT, CONVERT(DECIMAL(18,12), RAND(@seed)) * @multiplier)
    END AS name_id_first
    ,n.NameFirst
FROM
(
    SELECT
        ROW_NUMBER() OVER (ORDER BY i.NameFirst) AS name_index
        i.NameFirst
    FROM
    (
        SELECT DISTINCT        
            LTRIM(RTRIM(c.NameFirst)) AS NameFirst   
        FROM
            bridge.dbo.vwSLCustomer AS c
    ) AS i
) AS n