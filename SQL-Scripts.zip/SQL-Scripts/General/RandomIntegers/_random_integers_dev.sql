
--DECLARE @in_seed      INT = DATEPART(NANOSECOND, GETDATE())
DECLARE @in_digits    TINYINT = 9
DECLARE @in_min_value INT = 0 -- 1
DECLARE @in_max_value INT = 0 -- 2147483647



--DECLARE @MINUTES    INT = DATEPART(MINUTE, GETDATE())
--DECLARE @NANOSECOND INT = DATEPART(NANOSECOND, GETDATE())
--DECLARE @DIGITS     INT = 9
DECLARE @seed       INT = DATEPART(NANOSECOND, GETDATE())
DECLARE @multiplier INT = POWER(10, @in_digits)


--SELECT
--    @MINUTES AS [Minutes]
--    ,@NANOSECOND AS [NanoSeconds]

--SELECT POWER(10, 9)
--SELECT 
--    @multiplier AS [Multiplier]

SELECT
    CASE 
        WHEN @in_min_value > 0 AND @in_max_value > 0 THEN (CONVERT(INT, CONVERT(DECIMAL(18,12), RAND(@seed)) * @multiplier) % @in_max_value) + @in_min_value
        WHEN @in_min_value = 0 AND @in_max_value > 0 THEN (CONVERT(INT, CONVERT(DECIMAL(18,12), RAND(@seed)) * @multiplier) % @in_max_value)
        ELSE CONVERT(INT, CONVERT(DECIMAL(18,12), RAND(@seed)) * @multiplier)
    END AS random_value
    --,RAND(@seed) AS raw_random
    --,CONVERT(INT, CONVERT(DECIMAL(18,12), RAND(@seed)) * @multiplier) random_of_x_digits
    --,(CONVERT(INT, CONVERT(DECIMAL(18,12), RAND(@seed)) * @multiplier) % CASE WHEN @in_max_value = 0 THEN 1 ELSE @in_max_value END) AS random_with_max_only

