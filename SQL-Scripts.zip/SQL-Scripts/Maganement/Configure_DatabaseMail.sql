 
use master 
go 
sp_configure 'show advanced options',1 
go 
reconfigure with override 
go 
sp_configure 'Database Mail XPs',1 
--go 
--sp_configure 'SQL Mail XPs',0 
go 
reconfigure 
go 
 
-------------------------------------------------------------------------------------------------- 
-- BEGIN Mail Settings SQLMail 
-------------------------------------------------------------------------------------------------- 
IF NOT EXISTS(SELECT * FROM msdb.dbo.sysmail_profile WHERE  name = 'SQLMail')  
  BEGIN 
    --CREATE Profile [SQLMail] 
    EXECUTE msdb.dbo.sysmail_add_profile_sp 
      @profile_name = 'SQLMail', 
      @description  = 'Internal SQL Mail'; 
  END --IF EXISTS profile 
   
  IF NOT EXISTS(SELECT * FROM msdb.dbo.sysmail_account WHERE  name = 'SQL Mail') 
  BEGIN 
    --CREATE Account [SQL Mail] 
    EXECUTE msdb.dbo.sysmail_add_account_sp 
    @account_name            = 'SQL Mail', 
    @email_address           = 'sqlexec@consumerdirectonline.net', 
    @display_name            = 'SQL Mail', 
    @replyto_address         = 'noreply@consumerdirectonline.net', 
    @description             = 'Used for job notifications and alerts', 
    @mailserver_name         = 'mail.consumerdirectonline.net', 
    @mailserver_type         = 'SMTP', 
    @port                    = '25', 
    @username                =  NULL , 
    @password                =  NULL ,  
    @use_default_credentials =  0 , 
    @enable_ssl              =  0 ; 
  END --IF EXISTS  account 
   
IF NOT EXISTS(SELECT * 
              FROM msdb.dbo.sysmail_profileaccount pa 
                INNER JOIN msdb.dbo.sysmail_profile p ON pa.profile_id = p.profile_id 
                INNER JOIN msdb.dbo.sysmail_account a ON pa.account_id = a.account_id   
              WHERE p.name = 'SQLMail' 
                AND a.name = 'SQL Mail')  
  BEGIN 
    -- Associate Account [SQL Mail] to Profile [SQLMail] 
    EXECUTE msdb.dbo.sysmail_add_profileaccount_sp 
      @profile_name = 'SQLMail', 
      @account_name = 'SQL Mail', 
      @sequence_number = 1 ; 
  END  
--IF EXISTS associate accounts to profiles 
--------------------------------------------------------------------------------------------------- 
-- Drop Settings For SQLMail 
-------------------------------------------------------------------------------------------------- 
/* 
IF EXISTS(SELECT * 
            FROM msdb.dbo.sysmail_profileaccount pa 
              INNER JOIN msdb.dbo.sysmail_profile p ON pa.profile_id = p.profile_id 
              INNER JOIN msdb.dbo.sysmail_account a ON pa.account_id = a.account_id   
            WHERE p.name = 'SQLMail' 
              AND a.name = 'SQL Mail') 
  BEGIN 
    EXECUTE msdb.dbo.sysmail_delete_profileaccount_sp @profile_name = 'SQLMail',@account_name = 'SQL Mail' 
  END  
IF EXISTS(SELECT * FROM msdb.dbo.sysmail_account WHERE  name = 'SQL Mail') 
  BEGIN 
    EXECUTE msdb.dbo.sysmail_delete_account_sp @account_name = 'SQL Mail' 
  END 
IF EXISTS(SELECT * FROM msdb.dbo.sysmail_profile WHERE  name = 'SQLMail')  
  BEGIN 
    EXECUTE msdb.dbo.sysmail_delete_profile_sp @profile_name = 'SQLMail' 
  END 
*/ 
  