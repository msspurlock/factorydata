USE [msdb]
GO

/****** Object:  Operator [SQL_MGMT]    Script Date: 6/18/2019 3:14:07 PM ******/
IF  EXISTS (SELECT name FROM msdb.dbo.sysoperators WHERE name = N'SQL_MGMT')
EXEC msdb.dbo.sp_delete_operator @name=N'SQL_MGMT'
GO

/****** Object:  Operator [SQL_MGMT]    Script Date: 6/18/2019 3:14:07 PM ******/
EXEC msdb.dbo.sp_add_operator @name=N'SQL_MGMT', 
		@enabled=1, 
		@weekday_pager_start_time=90000, 
		@weekday_pager_end_time=180000, 
		@saturday_pager_start_time=90000, 
		@saturday_pager_end_time=180000, 
		@sunday_pager_start_time=90000, 
		@sunday_pager_end_time=180000, 
		@pager_days=0, 
		@email_address=N'SQL_MGMT@consumerdirectcare.com', 
		@category_name=N'[Uncategorized]'
GO


