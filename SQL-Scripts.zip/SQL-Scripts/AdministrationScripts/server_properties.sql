

SELECT 
	CAST(SERVERPROPERTY('ServerName') AS NVARCHAR(128))    AS [ServerName]
	,CAST(SERVERPROPERTY('InstanceName') AS NVARCHAR(128)) AS [InstanceName]
	,CAST(SERVERPROPERTY('MachineName') AS VARCHAR(200))   AS [MachineName]
	,CAST(SERVERPROPERTY('ProductVersion') AS VARCHAR(15)) AS [ProductVersion]
	,CAST(SERVERPROPERTY('Edition') AS VARCHAR(25))        AS [Edition]


