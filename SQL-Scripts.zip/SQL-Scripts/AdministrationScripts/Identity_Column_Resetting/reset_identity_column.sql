USE [Eligibility]
GO
DBCC CHECKIDENT   
(   
    'Plan'
)  
GO

USE [Eligibility]
GO
DBCC CHECKIDENT   
(   
    'Coverage'
)  
GO
