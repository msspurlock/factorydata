ALTER PROCEDURE [dbo].[xmaintTraceLoginSessionsStart] @login NVARCHAR(256)
AS 

-- Create a Queue 
DECLARE @rc INT 
DECLARE @TraceID INT 
DECLARE @maxfilesize bigint 
SET @maxfilesize = 5 
DECLARE @filename NVARCHAR(245) 
/*
Fails because the filename is from the SQL server's perspective and permissions are unknown.
*/
SET @filename = 'g:\mssql\brt_trace_by_login_' 
   + REPLACE(CONVERT(NVARCHAR(100),@login), '\', '_')
   + '_d' 
   + REPLACE(CONVERT(VARCHAR, GETDATE(),111),'/','') 
   + REPLACE(CONVERT(VARCHAR, GETDATE(),108),':','') 

EXEC @rc = sp_trace_create @TraceID output, 2, @filename, @maxfilesize, NULL 
IF (@rc != 0) GOTO error 

-- Set the events 
DECLARE @on bit 
SET @on = 1 
EXEC sp_trace_setevent @TraceID, 12, 1, @on 
EXEC sp_trace_setevent @TraceID, 12, 12, @on 
EXEC sp_trace_setevent @TraceID, 12, 14, @on 

-- Set the Filters 
DECLARE @intfilter INT 
DECLARE @bigintfilter bigint 
-- SPID
--EXEC sp_trace_setfilter @TraceID, 12, 1, 0, @spid 
-- username
EXEC sp_trace_setfilter @TraceID, 11, 0, 0, @login 

-- Set the trace status to start 
EXEC sp_trace_setstatus @TraceID, 1 

-- display trace id for future references 
SELECT TraceID=@TraceID 
GOTO finish 

error: 
SELECT ErrorCode=@rc 

finish: 

