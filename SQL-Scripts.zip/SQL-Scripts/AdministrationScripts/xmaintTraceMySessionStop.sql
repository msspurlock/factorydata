CREATE PROCEDURE [dbo].[xmaintTraceMySessionStop] @traceId INT 
AS 
EXEC sp_trace_setstatus @traceId,0 
EXEC sp_trace_setstatus @traceId,2 

