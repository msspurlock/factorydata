SELECT
	name
FROM
	sys.sysdatabases 
WHERE
	name LIKE '%APP'
	OR name = 'MHSBASE'
ORDER BY
	name
