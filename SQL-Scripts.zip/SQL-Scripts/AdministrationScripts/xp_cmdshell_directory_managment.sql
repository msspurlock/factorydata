/*
EXEC xp_cmdshell 'mkdir d:\Backups'
EXEC xp_cmdshell 'dir d:\'
EXEC xp_cmdshell 'mkdir d:\Backups\Full'
EXEC xp_cmdshell 'mkdir d:\Backups\Logs'
EXEC xp_cmdshell 'mkdir d:\Backups\Full\Files'
EXEC xp_cmdshell 'mkdir d:\Backups\Logs\Files'
*/

/*
EXEC xp_cmdshell 'mkdir c:\DM\1111-11-11'
EXEC xp_cmdshell 'mkdir c:\DM\1111-11-11\Errors'
EXEC xp_cmdshell 'mkdir c:\DM\1111-11-11\Success'
EXEC xp_cmdshell 'dir c:\DM\1111-11-11'
--06/02/2017  02:55 PM    <DIR>          2017-06-02T14-55-53-660-CDNMAPP-P1
EXEC xp_cmdshell 'dir c:\DM\2017-06-02T14-55-53-660-CDNMAPP-P1'
*/

/*
EXEC xp_cmdshell 'dir c:\DM\2017-06-02T14-55-53-660-CDNMAPP-P1\Errors'
EXEC xp_cmdshell 'dir c:\DM\2017-06-02T14-55-53-660-CDNMAPP-P1\Success'
*/


--EXEC xp_cmdshell 'dir F:\MSSQL\UTEX\Backup\Files\UTEXDB'
--EXEC xp_cmdshell 'dir F:\MSSQL\UTEX\Backup\Files'
EXEC xp_cmdshell 'dir \\LYNSQLHV01\I$'
EXEC xp_cmdshell 'copy F:\MSSQL\UTEX\Backup\Files\UTEXDB\UTEXDB_backup_2017_06_23_1028.bak \\LYNSQLHV01\I$'
EXEC xp_cmdshell 'dir \\LYNSQLHV01\I$'
