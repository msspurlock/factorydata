--A) IMPORTANT - VALIDATE DESTINATION DIRECTORY HAS MSSQLSERVER ACCESS PERMISSIONS
--   BEFORE STARTING THIS PROCESS.


--1)  Run the following statement.  
--THESE DON'T WORK WELL BY THEMSELVES.  The close all active connections offered by the GUI 
--seems to be the trick.
ALTER DATABASE [CDCOCRMTEST_MSCRM] SET OFFLINE;  
ALTER DATABASE [CDMSCRM_MSCRM] SET OFFLINE;  
ALTER DATABASE [CRM2016SAND_MSCRM] SET OFFLINE;  
ALTER DATABASE [MSCRM_CONFIG] SET OFFLINE;  
ALTER DATABASE [PLAY_MSCRM] SET OFFLINE;  


--2)  Move the file or files to the new location. 


--3)  For each file moved, run the following statement. 
ALTER DATABASE [CDCOCRMTEST_MSCRM] MODIFY FILE ( NAME = mscrm, FILENAME = 'H:\MSSQL\Data\CDCOCRMTEST_MSCRM.mdf' );  
ALTER DATABASE [CDMSCRM_MSCRM] MODIFY FILE ( NAME = mscrm, FILENAME = 'H:\MSSQL\Data\CDMSCRM_MSCRM.mdf' );  
ALTER DATABASE [CRM2016SAND_MSCRM] MODIFY FILE ( NAME = mscrm, FILENAME = 'H:\MSSQL\Data\CRM2016SAND_MSCRM.mdf' );  
ALTER DATABASE [MSCRM_CONFIG] MODIFY FILE ( NAME = MSCRM_CONFIG, FILENAME = 'H:\MSSQL\Data\MSCRM_CONFIG.mdf' );  
ALTER DATABASE [PLAY_MSCRM] MODIFY FILE ( NAME = mscrm, FILENAME = 'H:\MSSQL\Data\PLAY_MSCRM.mdf' );  


--4)  Run the following statement. 
ALTER DATABASE [CDCOCRMTEST_MSCRM] SET ONLINE;  
ALTER DATABASE [CDMSCRM_MSCRM] SET ONLINE;  
ALTER DATABASE [CRM2016SAND_MSCRM] SET ONLINE;  
ALTER DATABASE [MSCRM_CONFIG] SET ONLINE;  
ALTER DATABASE [PLAY_MSCRM] SET ONLINE;  


--5)  Verify the file change by running the following query. 
SELECT name, physical_name AS CurrentLocation, state_desc  
FROM sys.master_files  
WHERE database_id = DB_ID(N'CDCOCRMTEST_MSCRM');  

SELECT name, physical_name AS CurrentLocation, state_desc  
FROM sys.master_files  
WHERE database_id = DB_ID(N'CDMSCRM_MSCRM');  

SELECT name, physical_name AS CurrentLocation, state_desc  
FROM sys.master_files  
WHERE database_id = DB_ID(N'CRM2016SAND_MSCRM');  

SELECT name, physical_name AS CurrentLocation, state_desc  
FROM sys.master_files  
WHERE database_id = DB_ID(N'MSCRM_CONFIG');  

SELECT name, physical_name AS CurrentLocation, state_desc  
FROM sys.master_files  
WHERE database_id = DB_ID(N'PLAY_MSCRM');  

