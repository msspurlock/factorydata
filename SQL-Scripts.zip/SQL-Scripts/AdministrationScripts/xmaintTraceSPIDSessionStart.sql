USE [ISDB]
GO

/****** Object:  StoredProcedure [dbo].[xmaintTraceSPIDSessionStart]    Script Date: 3/31/2017 1:01:25 PM ******/
DROP PROCEDURE [dbo].[xmaintTraceSPIDSessionStart]
GO

/****** Object:  StoredProcedure [dbo].[xmaintTraceSPIDSessionStart]    Script Date: 3/31/2017 1:01:25 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[xmaintTraceSPIDSessionStart] @spid INT 
AS 

-- Create a Queue 
DECLARE @rc INT 
DECLARE @TraceID INT 
DECLARE @maxfilesize bigint 
SET @maxfilesize = 5 
DECLARE @filename NVARCHAR(245) 
/*
Fails because the filename is from the SQL server's perspective and permissions are unknown.
*/
SET @filename = 'g:\mssql\brt_trace_by_spid_' 
   + CONVERT(NVARCHAR(10),@spid) 
   + '_d' 
   + REPLACE(CONVERT(VARCHAR, GETDATE(),111),'/','') 
   + REPLACE(CONVERT(VARCHAR, GETDATE(),108),':','') 

EXEC @rc = sp_trace_create @TraceID output, 2, @filename, @maxfilesize, NULL 
IF (@rc != 0) GOTO error 

-- Set the events 
DECLARE @on bit 
SET @on = 1 
EXEC sp_trace_setevent @TraceID, 12, 1, @on 
EXEC sp_trace_setevent @TraceID, 12, 12, @on 
EXEC sp_trace_setevent @TraceID, 12, 14, @on 

-- Set the Filters 
DECLARE @intfilter INT 
DECLARE @bigintfilter bigint 
EXEC sp_trace_setfilter @TraceID, 12, 1, 0, @spid 

-- Set the trace status to start 
EXEC sp_trace_setstatus @TraceID, 1 

-- display trace id for future references 
SELECT TraceID=@TraceID 
GOTO finish 

error: 
SELECT ErrorCode=@rc 

finish: 


GO


