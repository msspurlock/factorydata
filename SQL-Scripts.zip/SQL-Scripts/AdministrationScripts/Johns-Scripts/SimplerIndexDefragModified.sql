--dbcc showcontig

--use JobEngineCO
set nocount on
go

declare @fraglimit int
		,@Rebuildcmd varchar(max)
		,@DB_ID INT
		,@Sql varchar(max)
		,@dbname varchar(max)
		,@processrebuild bit 
		,@selectcmd varchar(max)
		,@showall bit
		,@useReorganize bit


select @useReorganize = 0

--SELECT @FRAGLIMIT = 1
select @fraglimit = coalesce(@fraglimit,5)
select @fraglimit
SELECT @DB_id = DB_id()

select @processrebuild = 1
select @showall = 0

SELECT  frag.[object_id] oid,
        schema_name(o.schema_id) [schema],
        o.name [table],
        i.name [index],
        i.index_id indid,
        ps.function_id partitionScheme,
        frag.partition_number [partition],
        frag.page_count,
        frag.avg_fragmentation_in_percent,
		frag.avg_page_space_used_in_percent,
        'ALTER INDEX ' + quotename(i.name) 
        + ' ON ' + quotename(schema_name(o.schema_id)) + '.'
        + quotename( o.name ) + ' REBUILD'
        + CASE WHEN ps.function_id IS NOT NULL
               THEN ' PARTITION = '
                    + CAST(frag.partition_number AS varchar(100))
               ELSE ''
          END + ';' + CHAR(13) AS rebuildCmd
		,i.type
		,'Select count(*),' + '''' + o.name + '''' + ' from ' + quotename(schema_name(o.schema_id)) + '.' + quotename(o.name)  as SelectCmd 
INTO    #fraggedIndexes
FROM    sys.dm_db_index_physical_stats(@DB_id, DEFAULT, DEFAULT, DEFAULT,
                                       'SAMPLED') frag
        INNER JOIN sys.objects AS o ON o.object_id = frag.object_id
        INNER JOIN sys.indexes AS i ON i.object_id = frag.object_id
                                       AND i.index_id = frag.index_id
        LEFT JOIN sys.partition_schemes ps ON i.data_space_id = ps.data_space_id
WHERE   1=1
--and		o.name = 'xservicelog'
and		(frag.avg_fragmentation_in_percent > @fragLimit
--		OR (100.0 - avg_page_space_used_in_percent) > @FRAGLIMIT
		)
        AND i.[type] IN ( 1, 2 ) -- clustered or nonclustered, not heap or XML
--		and o.name = 'accthist'
        AND page_count > 100 
ORDER By o.name;

select * from #fraggedindexes

update #fraggedindexes
set rebuildcmd = 
 'Alter index ' + quotename([index]) + ' on ' + quotename([schema]) + '.' + quotename([table]) +
	CASE when [partitionScheme] is not null 
		then 'Partion = ' +  CAST([partition] AS varchar(100))
		else ''
	end +
	Case when avg_fragmentation_in_percent < 30 and @useReorganize = 1 then ' REORGANIZE;'
		else ' Rebuild; '
		--with (online = on);'
	end

select [schema],[table],max(avg_fragmentation_in_percent) as MaxFrag,
'Alter Index All on ' + quotename([schema]) + '.' + quotename([table]) + ' '
	+ Case when max(avg_fragmentation_in_percent) < 30 then 'rebuild;'
		 else 'Rebuild;'
	end as Rebuildcmd,selectcmd
into #IndexFix
from #fraggedindexes
group by [schema],[table],[selectcmd]

select * from #IndexFix

if @showall = 1
begin
while exists(select 1 from #IndexFix)
begin
	SELECT TOP 1  @REBUILDCMD = REBUILDCMD,@selectcmd = selectcmd FROM #IndexFix
	print @selectcmd
	print 'go'
	PRINT @REBUILDCMD
	print 'go'
	print @selectcmd
--	print 'go'

	select @processrebuild = 0
	If @ProcessRebuild = 1 --Actually perform the rebuild
	begin
		EXEC (@REBUILDCMD)
	end
	DELETE FROM #IndexFix WHERE REBUILDCMD = @REBUILDCMD
end
end

print '--END INDEX REBUILD ALL'
print '--START INDEX REBUILD SPECIFIC INDEX'

while exists(select 1 from #fraggedIndexes)
begin
	SELECT TOP 1  @REBUILDCMD = REBUILDCMD,@selectcmd = selectcmd FROM #FraggedIndexes
	print @selectcmd
	print 'go'
	PRINT @REBUILDCMD
	print  'go'
	print @selectcmd
--	print 'go'

	select @processrebuild = 0
	If @ProcessRebuild = 1 --Actually perform the rebuild
	begin
		EXEC (@REBUILDCMD)
	end
	DELETE FROM #fraggedindexes WHERE REBUILDCMD = @REBUILDCMD
end


--
drop table #Indexfix
drop table #fraggedindexes
go
set nocount off
go

print 'GO'
print '-- exec sp_updatestats'

