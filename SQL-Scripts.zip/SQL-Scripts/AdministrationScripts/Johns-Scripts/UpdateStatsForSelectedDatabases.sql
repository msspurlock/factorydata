--EXEC sp_MSforeachdb 'IF ''?''  NOT IN (''tempdb'',''msdb'',''master'',''model'')
--BEGIN
--                use [?];
--                print db_name()
--                exec sp_updatestats
--END'

declare @db varchar(50)

declare c1 cursor for select  name from sys.databases where database_id > 4 --and name like '%app'
order by name

open c1

fetch next from c1 into @db

while @@fetch_status = 0
begin
print 'USE ' + @db
print 'print db_name()'
print 'exec sp_updatestats'
print 'go'
print 'print ''END '' + db_name()'
fetch next from c1 into @db 
end

close c1
deallocate c1
