USE msdb
GO
DECLARE @DaysToKeepHistory DATETIME
SET @DaysToKeepHistory = CONVERT(VARCHAR(10), DATEADD(dd, -183, GETDATE()), 101)

select @daystokeephistory = '1/01/2017'

select min(backup_start_date), min(backup_finish_date) from backupset
select @daystokeephistory

----To speed up the backup history deletion I created 3 indexes:
CREATE NONCLUSTERED INDEX [IX_backupset_database_name_backup_set_id]
ON [dbo].[backupset] ([database_name]) INCLUDE ([backup_set_id])
CREATE NONCLUSTERED INDEX [IX_backupset_database_name_media_set_id]
ON [dbo].[backupset] ([database_name]) INCLUDE ([media_set_id])
CREATE NONCLUSTERED INDEX [_ped_backupset_media_set_id]
ON [dbo].[backupset] ([media_set_id])


EXEC sp_delete_backuphistory @DaysToKeepHistory
--GO 

DROP INDEX [IX_backupset_database_name_backup_set_id] ON [dbo].[backupset] WITH ( ONLINE = OFF )
Drop Index [IX_backupset_database_name_media_set_id] on [dbo].[backupset] with ( online = off)
drop index [_ped_backupset_media_set_id] ON [dbo].[backupset] with ( online = off)
--GO 


select min(backup_start_date), min(backup_finish_date) from backupset
--
--select * from sysjobhistory order by run_date
select count(*) from sysjobhistory
--
exec sp_purge_jobhistory null, null, @daystokeephistory

--select * from sysjobhistory
select count(*) from sysjobhistory

--select * from sysmaintplan_log order by start_time
--select * from sysmaintplan_logdetail
select count(*) from sysmaintplan_log
select count(*) from sysmaintplan_logdetail

exec sp_maintplan_delete_log null,null,@daystokeephistory

--select * from sysmaintplan_log order by start_time
--select * from sysmaintplan_logdetail
select count(*) from sysmaintplan_log
select count(*) from sysmaintplan_logdetail

/*


DECLARE @PurgeDate datetime = dateadd(dd,-180,getdate());

select @purgedate
--return
EXEC msdb.dbo.sysmail_delete_mailitems_sp @sent_before=@PurgeDate;

*/

--CHECK SIZES OF TEMPDB FILES!
--CHECK SIZE OF REPORTSERVERTEMPDB LOG FILE - KEEP IT AT 500 MB