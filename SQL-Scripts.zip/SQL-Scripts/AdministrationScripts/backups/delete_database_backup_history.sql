
EXEC [msdb].[dbo].[sp_delete_database_backuphistory] @database_name = 'DBAAdmin'  
