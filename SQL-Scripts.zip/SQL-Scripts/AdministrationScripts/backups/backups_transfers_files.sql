SELECT
	ti.[database_name]
	,ti.source_filename
FROM
	ISDB.dbo.xBackupTransfersItems AS ti
WHERE
	ti.backup_copy_job_id = 1
ORDER BY
	ti.[database_name]
	,ti.source_filename
