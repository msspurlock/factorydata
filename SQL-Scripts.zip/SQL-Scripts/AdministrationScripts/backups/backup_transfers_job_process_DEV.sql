
--SELECT GETDATE()


DECLARE
	@backup_copy_job_id  INT
	,@successful_count   INT   --OUTPUT
	,@failed_count       INT   --OUTPUT
	,@skipped_count      INT   --OUTPUT


SET @backup_copy_job_id = 1	


--SELECT backup_xfer_status_id, backup_xfer_status_name FROM ISDB.dbo.xBackupTransfersStatus
--backup_xfer_status_id backup_xfer_status_name
----------------------- --------------------------------------------------
--1                     Scheduled
--2                     InProgress
--3                     Finished
--4                     Failed


DECLARE @backup_copy_job_item_id  INT
DECLARE @prev_item_id             INT

DECLARE @source_files    VARCHAR(500)
DECLARE @destination_dir VARCHAR(255)

DECLARE @start_dt_tm     DATETIME
DECLARE @finished_dt_tm  DATETIME
DECLARE @files_copied    INT
DECLARE @successful_yn   BIT
DECLARE @elapsed_time    VARCHAR(10)

SELECT TOP 1
	@backup_copy_job_item_id = i.backup_copy_job_item_id
	,@source_files           = i.source_filename_path
	,@destination_dir        = i.destination_path
FROM
	ISDB.dbo.xBackupTransfersItems AS i
WHERE
	i.backup_copy_job_id        = @backup_copy_job_id
	AND i.backup_xfer_status_id = 1
ORDER BY
	i.sequence_no --DESC


WHILE @backup_copy_job_item_id IS NOT NULL
BEGIN

	--SELECT
	--	@backup_copy_job_item_id AS [Backup Copy Job Item Id]
	--	,@source_files           AS [Source Files]
	--	,@destination_dir        AS [Destination Dir]

	SET @start_dt_tm     = GETDATE()
	SET @finished_dt_tm  = NULL
	SET @files_copied    = 0
	SET @successful_yn   = 0
	SET @elapsed_time    = ''


	UPDATE
		ISDB.dbo.xBackupTransfersItems
	SET
		backup_xfer_status_id = 2
		,started_dt_tm        = @start_dt_tm
	WHERE
		backup_copy_job_item_id = @backup_copy_job_item_id


	EXEC ISDB.dbo.ucmdFilesCopy
						@source_files
						,@destination_dir
						,@files_copied    OUTPUT
						,@successful_yn   OUTPUT

	SET @finished_dt_tm  = GETDATE()
	SET @elapsed_time    = ISDB.dbo.ToTimeSpanHoursMinutesSeconds(@start_dt_tm, @finished_dt_tm)


	UPDATE
		ISDB.dbo.xBackupTransfersItems
	SET
		backup_xfer_status_id = CASE WHEN @successful_yn = 1 THEN 3 ELSE 4 END
		,finished_dt_tm       = @finished_dt_tm
		,elapsed_time         = @elapsed_time
	WHERE
		backup_copy_job_item_id = @backup_copy_job_item_id


	SET @prev_item_id = @backup_copy_job_item_id
	SET @backup_copy_job_item_id = NULL


	SELECT TOP 1
		@backup_copy_job_item_id = i.backup_copy_job_item_id
		,@source_files           = i.source_filename_path
		,@destination_dir        = i.destination_path
	FROM
		ISDB.dbo.xBackupTransfersItems AS i
	WHERE
		i.backup_copy_job_id          = @backup_copy_job_id
		AND i.backup_xfer_status_id   = 1
		AND i.backup_copy_job_item_id > @prev_item_id
	ORDER BY
		i.sequence_no --DESC

END  -- WHILE




