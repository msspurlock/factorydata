SELECT
	[Database Name] AS "@name"
FROM
(
	SELECT 
		DB_NAME(mf.[database_id]) AS [Database Name], 
		LEFT(mf.physical_name, 1) AS drive_letter,
		mf.[file_id], 
		mf.[name], 
		mf.physical_name, 
		mf.[type],
		mf.[type_desc], 
		mf.[state],
		mf.state_desc,
		mf.is_percent_growth, 
		mf.growth,
		CONVERT(BIGINT, mf.growth/128.0) AS [Growth in MB], 
		CONVERT(BIGINT, mf.size/128.0) AS [Total Size in MB]
	FROM 
		sys.master_files AS mf WITH (NOLOCK)
	INNER JOIN
		sys.databases AS db
	ON
		db.database_id = mf.database_id
	WHERE
		DB_NAME(mf.[database_id]) NOT IN ('master', 'tempdb', 'model', 'msdb', 'test')
		AND mf.[type] = 0 -- rows/data
		AND mf.[state] = 0 -- online
) AS dbs
WHERE
	dbs.drive_letter = 'H'
FOR XML PATH('database'), ROOT('root')


SELECT
	[Database Name] AS "@name"
FROM
(
	SELECT 
		DB_NAME(mf.[database_id]) AS [Database Name], 
		LEFT(mf.physical_name, 1) AS drive_letter,
		mf.[file_id], 
		mf.[name], 
		mf.physical_name, 
		mf.[type],
		mf.[type_desc], 
		mf.[state],
		mf.state_desc,
		mf.is_percent_growth, 
		mf.growth,
		CONVERT(BIGINT, mf.growth/128.0) AS [Growth in MB], 
		CONVERT(BIGINT, mf.size/128.0) AS [Total Size in MB]
	FROM 
		sys.master_files AS mf WITH (NOLOCK)
	INNER JOIN
		sys.databases AS db
	ON
		db.database_id = mf.database_id
	WHERE
		DB_NAME(mf.[database_id]) NOT IN ('master', 'tempdb', 'model', 'msdb', 'test')
		AND mf.[type] = 0 -- rows/data
		AND mf.[state] = 0 -- online
) AS dbs
WHERE
	dbs.drive_letter = 'G'
FOR XML PATH('database'), ROOT('root')
