DECLARE @backup_copy_job_id INT

SELECT TOP 1
	@backup_copy_job_id = xfr.backup_copy_job_id
FROM
	ISDB.dbo.xBackupTransfers AS xfr
ORDER BY
	xfr.backup_copy_job_id DESC

SELECT @backup_copy_job_id AS [Backup Copy Job Id]

/*
UPDATE
	ISDB.dbo.xBackupTransfersItems
SET
	backup_xfer_status_id = 255
WHERE
	backup_copy_job_id = @backup_copy_job_id
*/
/*
SELECT
	*
FROM
	ISDB.dbo.xBackupTransfersItems AS xi
WHERE
	xi.backup_copy_job_id = @backup_copy_job_id
	AND xi.backup_type = 'D'
ORDER BY
	xi.sequence_no
*/

SELECT
	*
FROM
	ISDB.dbo.xBackupTransfersItems AS xi
WHERE
	xi.backup_copy_job_id = @backup_copy_job_id
ORDER BY
	xi.sequence_no

/*
SELECT DISTINCT [database_name] FROM ISDB.dbo.xBackupTransfersItems WHERE backup_copy_job_id = @backup_copy_job_id


SELECT
	xi.server_name
	,xi.[database_name]
	,xi.source_filename
	,xi.source_path
	--,xi.backup_set_id
	--,xi.media_set_id
	--,xi.destination_path
	--*
FROM
	ISDB.dbo.xBackupTransfersItems AS xi
WHERE
	xi.backup_copy_job_id = @backup_copy_job_id
	AND xi.[database_name] = 'CDWIAPP'
ORDER BY
	xi.database_name
	,xi.source_filename
*/