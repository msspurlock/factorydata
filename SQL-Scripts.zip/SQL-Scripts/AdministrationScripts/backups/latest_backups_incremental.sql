/*
TRUNCATE TABLE ISDB.dbo.xBackupTransfers
SELECT * FROM ISDB.dbo.xBackupTransfers
TRUNCATE TABLE ISDB.dbo.xBackupTransfersItems
SELECT * FROM ISDB.dbo.xBackupTransfersItems
*/
DECLARE
	@backup_copy_job_id INT
	,@server            SYSNAME
	,@start_dt_tm       DATETIME
	,@end_dt_tm         DATETIME
	--,@out_error_id      INT           OUTPUT
	--,@out_error_messge  VARCHAR(MAX)  OUTPUT

SET @backup_copy_job_id = 1
SET @server             = 'LYNSQLC01'
SET @start_dt_tm        = '2/16/2018 00:01'
SET @end_dt_tm          = '2/16/2018 04:00'


    SET NOCOUNT ON


	DECLARE @out_error_id      INT = 0
	DECLARE @out_error_messge  VARCHAR(MAX) = ''


	DECLARE @CRLF VARCHAR(2) = CHAR(13) + CHAR(10);
	DECLARE @parameters VARCHAR(1000)
	SET @parameters = '@server        = ' + ISNULL(@server, 'NULL') + @CRLF
	                + '@start_dt_tm   = ' + CASE WHEN @start_dt_tm IS NULL THEN 'NULL' ELSE CONVERT(VARCHAR(50), @start_dt_tm) END + @CRLF
	                + '@end_dt_tm     = ' + CASE WHEN @end_dt_tm IS NULL THEN 'NULL' ELSE CONVERT(VARCHAR(50), @end_dt_tm) END + @CRLF


	DECLARE @label VARCHAR(50)
	DECLARE @max_existing_sequence_no INT = 0

	SET @label = ''
	BEGIN TRY

		SELECT
			@max_existing_sequence_no = MAX(sequence_no)
		FROM
			ISDB.dbo.xBackupTransfersItems
		WHERE
			backup_copy_job_id = @backup_copy_job_id

	END TRY
	BEGIN CATCH
		EXEC ISDB.[dbo].[Log_Try_Catch_Error_Information_w_Return] @parameters, @label, @out_error_id OUTPUT, @out_error_messge OUTPUT
		GOTO exit_point
	END CATCH



	IF @backup_copy_job_id = 0
	BEGIN

		SET @label = 'Create Transfer'
		BEGIN TRY

			INSERT INTO
				ISDB.dbo.xBackupTransfers
			(
				--backup_copy_job_id  -- identity
				schedule_dt_tm_start
				,schedule_dt_tm_end
				,active
				,successfull_count
				,failed_count
				,skipped_count
				,backup_xfer_status_id
				,started_dt_tm
				,finished_dt_tm
				,created_dt_tm
			)
			VALUES
			(
				@start_dt_tm
				,@end_dt_tm
				,1
				,0
				,0
				,0
				,1
				,NULL
				,NULL
				,GETDATE()
			)

			SELECT @backup_copy_job_id = SCOPE_IDENTITY()

		END TRY
		BEGIN CATCH
			EXEC ISDB.[dbo].[Log_Try_Catch_Error_Information_w_Return] @parameters, @label, @out_error_id OUTPUT, @out_error_messge OUTPUT
			GOTO exit_point
		END CATCH

	END  -- IF @backup_copy_job_id = 0


	SELECT @backup_copy_job_id AS [Backup Copy Job Id]


	SET @label = 'Set @full_backups_command'
	BEGIN TRY

		;WITH last_full_backup AS
		(
			SELECT
				--@backup_copy_job_id AS backup_copy_job_id
				--,@server AS server_name
				afb.backup_type_id
				,afb.[database_name]
				,afb.backup_start_date
				,afb.backup_set_id
				,afb.media_set_id
				,afb.physical_device_name AS source_filename_path
				--,ROW_NUMBER() OVER (ORDER BY afb.backup_type_id, afb.[database_name], afb.backup_start_date) AS sequence_no
				--,afb.backup_size_bytes AS file_size_bytes
				--,afb.backup_size_megabytes AS file_size_megabytes
				,afb.compressed_backup_size_bytes AS file_size_bytes
				,afb.compressed_backup_size_megabytes AS file_size_megabytes
				,afb.backup_path AS source_path
				,afb.backup_filename AS source_filename
				,afb.destination_path
				,'COPY ' + afb.physical_device_name + ' ' + afb.destination_path AS command
				,1 AS backup_xfer_status_id
				,NULL AS started_dt_tm
				,NULL AS finished_dt_tm
				,'' AS elapsed_time
				--,afb.backup_start_date AS full_backup_start_date
				--,afb.backup_finish_date AS full_backup_finish_date
				--,afb.has_backup_checksums AS full_backup_has_checksums
				--,afb.is_damaged AS full_backup_is_damaged
				,GETDATE() AS created_dt_tm
			FROM
			(
				SELECT 
					bus.[database_name]
					,bus.backup_set_id
					,bus.media_set_id
					,bus.type AS backup_type_id
					,bus.backup_start_date
					,bus.backup_finish_date
					,bus.has_backup_checksums
					,bus.is_damaged
					,bus.backup_size AS backup_size_bytes
					,CONVERT(DECIMAL(19,1), bus.backup_size / 1000000.0) AS backup_size_megabytes
					,bus.compressed_backup_size AS compressed_backup_size_bytes
					,CONVERT(DECIMAL(19,1), bus.compressed_backup_size / 1000000.0) AS compressed_backup_size_megabytes
					--,bus.[name] AS backup_set_name
					,bmf.physical_device_name
					--,SUBSTRING(bmf.physical_device_name, 0, PATINDEX('%' + bus.[name] + '%', bmf.physical_device_name)) AS backup_path
					--,CHARINDEX('\', REVERSE(bmf.physical_device_name)) AS reverse_index
					--,LEN(bmf.physical_device_name) AS pd_length
					,'\\HQSQLDR01' + 
						CASE SUBSTRING(bmf.physical_device_name, 0, 2)
							WHEN 'W' THEN '\WBackups'
							WHEN 'X' THEN '\XBackups'
							ELSE '\XBackups'
						END + '\Files\' + bus.[database_name] AS destination_path
					,SUBSTRING(bmf.physical_device_name, 0, 2) AS source_drive
					,SUBSTRING(bmf.physical_device_name, 0, (LEN(bmf.physical_device_name) - CHARINDEX('\', REVERSE(bmf.physical_device_name)) + 2)) AS backup_path
					,SUBSTRING(bmf.physical_device_name, (LEN(bmf.physical_device_name) - CHARINDEX('\', REVERSE(bmf.physical_device_name)) + 2), 250) AS backup_filename
					,ROW_NUMBER() OVER (PARTITION BY bus.[database_name]
										ORDER BY bus.backup_finish_date DESC ) AS backupset_index_desc
				FROM 
					[LYNSQLC01].msdb.dbo.backupmediafamily AS bmf
				INNER JOIN 
					[LYNSQLC01].msdb.dbo.backupset AS bus
				ON 
					bus.media_set_id = bmf.media_set_id
				WHERE 
					bus.[type] = 'D'
					AND bus.backup_start_date  IS NOT NULL
					AND bus.backup_finish_date IS NOT NULL
					AND bus.[database_name] NOT IN ('master', 'model', 'msdb', 'tempdb')
			) AS afb
			WHERE
				afb.backupset_index_desc = 1
				AND afb.source_drive = 'W'
		)
		INSERT INTO
			ISDB.dbo.xBackupTransfersItems
		(
			--backup_copy_job_item_id -- identity column
			backup_copy_job_id
			,server_name
			,[database_name]
			,backup_set_id
			,media_set_id
			,backup_type
			,source_filename_path
			,sequence_no
			,file_size_bytes
			,file_size_megabytes
			,source_path
			,source_filename
			,destination_path
			,command
			,backup_xfer_status_id
			,started_dt_tm
			,finished_dt_tm
			,elapsed_time
			,created_dt_tm
		)
		SELECT
			@backup_copy_job_id
			,@server AS server_name
			,abu.[database_name]
			,abu.backup_set_id
			,abu.media_set_id
			,abu.backup_type_id
			,abu.source_filename_path
			,ROW_NUMBER() OVER (ORDER BY abu.backup_type_id, abu.file_size_bytes DESC, abu.[database_name], abu.backup_start_date) + ISNULL(@max_existing_sequence_no, 0) AS sequence_no
			,abu.file_size_bytes
			,abu.file_size_megabytes
			,abu.source_path
			,abu.source_filename
			,abu.destination_path
			,abu.command
			,abu.backup_xfer_status_id
			,abu.started_dt_tm
			,abu.finished_dt_tm
			,abu.elapsed_time
			,abu.created_dt_tm
			--,backup_start_date
		FROM
		(
			SELECT
				backup_type_id
				,[database_name]
				,backup_start_date
				,backup_set_id
				,media_set_id
				,source_filename_path
				,file_size_bytes
				,file_size_megabytes
				,source_path
				,source_filename
				,destination_path
				,command
				,backup_xfer_status_id
				,started_dt_tm
				,finished_dt_tm
				,elapsed_time
				,created_dt_tm
			FROM
				last_full_backup

			UNION

			SELECT
				--@backup_copy_job_id AS backup_copy_job_id
				--,@server AS server_name
				afb.backup_type_id
				,afb.[database_name]
				,afb.backup_start_date
				,afb.backup_set_id
				,afb.media_set_id
				,afb.physical_device_name AS source_filename_path
				--,ROW_NUMBER() OVER (ORDER BY afb.backup_type_id, afb.[database_name], afb.backup_start_date) AS sequence_no
				--,afb.backup_size_bytes AS file_size_bytes
				--,afb.backup_size_megabytes AS file_size_megabytes
				,afb.compressed_backup_size_bytes AS file_size_bytes
				,afb.compressed_backup_size_megabytes AS file_size_megabytes
				,afb.backup_path AS source_path
				,afb.backup_filename AS source_filename
				,afb.destination_path
				,'COPY ' + afb.physical_device_name + ' ' + afb.destination_path AS command
				,1 AS backup_xfer_status_id
				,NULL AS started_dt_tm
				,NULL AS finished_dt_tm
				,'' AS elapsed_time
				--,afb.backup_start_date AS full_backup_start_date
				--,afb.backup_finish_date AS full_backup_finish_date
				--,afb.has_backup_checksums AS full_backup_has_checksums
				--,afb.is_damaged AS full_backup_is_damaged
				,GETDATE() AS created_dt_tm
			FROM
			(
				SELECT
					bus.[database_name]
					,bus.backup_set_id
					,bus.media_set_id
					,bus.type AS backup_type_id
					,bus.backup_start_date
					,bus.backup_finish_date
					,bus.has_backup_checksums
					,bus.is_damaged
					,bus.backup_size AS backup_size_bytes
					,CONVERT(DECIMAL(19,1), bus.backup_size / 1000000.0) AS backup_size_megabytes
					,bus.compressed_backup_size AS compressed_backup_size_bytes
					,CONVERT(DECIMAL(19,1), bus.compressed_backup_size / 1000000.0) AS compressed_backup_size_megabytes
					--,bus.[name] AS backup_set_name
					,bmf.physical_device_name
					--,SUBSTRING(bmf.physical_device_name, 0, PATINDEX('%' + bus.[name] + '%', bmf.physical_device_name)) AS backup_path
					--,CHARINDEX('\', REVERSE(bmf.physical_device_name)) AS reverse_index
					--,LEN(bmf.physical_device_name) AS pd_length
					,'\\HQSQLDR01' + 
						CASE SUBSTRING(bmf.physical_device_name, 0, 2)
							WHEN 'W' THEN '\WBackups'
							WHEN 'X' THEN '\XBackups'
							ELSE '\XBackups'
						END + '\Files\' + bus.[database_name] AS destination_path
					,SUBSTRING(bmf.physical_device_name, 0, 2) AS source_drive
					,SUBSTRING(bmf.physical_device_name, 0, (LEN(bmf.physical_device_name) - CHARINDEX('\', REVERSE(bmf.physical_device_name)) + 2)) AS backup_path
					,SUBSTRING(bmf.physical_device_name, (LEN(bmf.physical_device_name) - CHARINDEX('\', REVERSE(bmf.physical_device_name)) + 2), 250) AS backup_filename
				FROM
					last_full_backup AS lf
				INNER JOIN 
					[LYNSQLC01].msdb.dbo.backupset AS bus
				ON 
					bus.[database_name] = lf.[database_name]
					AND bus.[type] = 'l'
					AND bus.backup_start_date >= lf.backup_start_date
					AND bus.backup_finish_date IS NOT NULL
					AND bus.[database_name] NOT IN ('master', 'model', 'msdb', 'tempdb')
				INNER JOIN
					[LYNSQLC01].msdb.dbo.backupmediafamily AS bmf
				ON
					bmf.media_set_id = bus.media_set_id
			) AS afb
			WHERE
				afb.source_drive = 'W'
		) AS abu
		LEFT OUTER JOIN
			ISDB.dbo.xBackupTransfersItems AS cur
		ON
			cur.backup_copy_job_id = @backup_copy_job_id
			AND cur.backup_set_id  = abu.backup_set_id
		WHERE
			cur.backup_set_id IS NULL

	END TRY
	BEGIN CATCH
		EXEC ISDB.[dbo].[Log_Try_Catch_Error_Information_w_Return] @parameters, @label, @out_error_id OUTPUT, @out_error_messge OUTPUT
		GOTO exit_point
	END CATCH


exit_point:


    SET NOCOUNT OFF



