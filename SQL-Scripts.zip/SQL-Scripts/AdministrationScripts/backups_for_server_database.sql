--CREATE PROC [dbo].[sql_status_latest_full_backups_previous_7_days_get] 
DECLARE
	@exec_id        INT
	,@server        SYSNAME
	,@end_dt_tm     DATETIME
	,@databasename  SYSNAME
	--,@out_error_id      INT           OUTPUT
	--,@out_error_messge  VARCHAR(MAX)  OUTPUT


SET @exec_id = 0
SET @server = 'LYNSQLC01'
SET @end_dt_tm = GETDATE()
SET @databasename = 'CDTXAPP'

    SET NOCOUNT ON


	DECLARE @out_error_id      INT = 0
	DECLARE @out_error_messge  VARCHAR(MAX) = ''


	DECLARE @CRLF VARCHAR(2) = CHAR(13) + CHAR(10);
	DECLARE @parameters VARCHAR(1000)
	SET @parameters = '@exec_id   = ' + CONVERT(VARCHAR(25), @exec_id) + @CRLF
	                + '@server    = ' + ISNULL(@server, 'NULL') + @CRLF
	                + '@end_dt_tm = ' + CONVERT(VARCHAR(25), @end_dt_tm) + @CRLF


	DECLARE @start_dt_tm DATETIME
	SET @start_dt_tm = DATEADD(day, -7, @end_dt_tm)

	--SELECT @start_dt_tm AS [Start Date/Time], @end_dt_tm AS [End Date/Time]

	DECLARE @label VARCHAR(50)

				SELECT 
					bus.[database_name]
					,bus.backup_set_id
					,bus.backup_start_date
					,bus.backup_finish_date
					,bus.has_backup_checksums
					,bus.is_damaged
					,CASE
						 WHEN bus.backup_finish_date IS NULL OR bus.is_damaged = 1 THEN 0
						 ELSE 1
					 END AS was_successful
					,CASE
						 WHEN bus.backup_finish_date IS NULL OR bus.is_damaged = 1 THEN 1
						 ELSE 0
					 END AS is_failed
					,backup_size AS backup_size_bytes
					,CONVERT(NUMERIC(20,1), backup_size / 1000000.0) AS backup_size_megabytes
					,bmf.physical_device_name AS filename_path
				FROM 
					msdb.dbo.backupset AS bus
				INNER JOIN 
					msdb.dbo.backupmediafamily AS bmf
				ON 
					bmf.media_set_id = bus.media_set_id 
				WHERE 
					--bus.[type] = 'D'
					bus.server_name           = @server
					AND bus.[database_name]   = @databasename
					AND bus.backup_start_date IS NOT NULL
					AND bus.backup_start_date BETWEEN @start_dt_tm AND @end_dt_tm

GOTO exit_point
	--SET @label = 'Delete Current'
	--BEGIN TRY
		
	--	-- delete current so we can get a new copy for whatever reason.
	--	DELETE FROM
	--		ISDB.dbo.sql_status_latest_full_backups_previous_7_days
	--	WHERE
	--		execution_id = @exec_id
	--		AND server_name = @server

	--END TRY
	--BEGIN CATCH
	--	EXEC ISDB.[dbo].[Log_Try_Catch_Error_Information_w_Return] @parameters, @label, @out_error_id OUTPUT, @out_error_messge OUTPUT
	--	INSERT INTO ISDB.dbo.sql_status_execution_errors (execution_id, error_id) VALUES (@exec_id, @out_error_id)
	--	GOTO exit_point
	--END CATCH


	DECLARE @params NVARCHAR(4000)

	SET @label = 'Set @params'
	BEGIN TRY

		SET @params = '@exec_id INT, @server SYSNAME, @start_dt_tm DATETIME, @end_dt_tm DATETIME'

	END TRY
	BEGIN CATCH
		EXEC ISDB.[dbo].[Log_Try_Catch_Error_Information_w_Return] @parameters, @label, @out_error_id OUTPUT, @out_error_messge OUTPUT
		INSERT INTO ISDB.dbo.sql_status_execution_errors (execution_id, error_id) VALUES (@exec_id, @out_error_id)
		GOTO exit_point
	END CATCH


	DECLARE @databases_command NVARCHAR(4000)


	SET @label = 'Set @databases_command'
	BEGIN TRY

		--SET @databases_command = N'
		;WITH last_weeks_backups AS
		(
			SELECT
				sfb.[database_name]
				,sfb.backup_set_id
				,sfb.backup_start_date
				,sfb.backup_finish_date
				,sfb.has_backup_checksums
				,sfb.is_damaged
				,sfb.was_successful
				,sfb.is_failed
				,ROW_NUMBER() OVER (PARTITION BY sfb.[database_name]
									ORDER BY 
										sfb.was_successful DESC --(1 or 0)
										,sfb.backup_finish_date DESC 
									) AS backupset_index_desc
			FROM
			(
				SELECT 
					bus.[database_name]
					,bus.backup_set_id
					,bus.backup_start_date
					,bus.backup_finish_date
					,bus.has_backup_checksums
					,bus.is_damaged
					,CASE
						 WHEN bus.backup_finish_date IS NULL OR bus.is_damaged = 1 THEN 0
						 ELSE 1
					 END AS was_successful
					,CASE
						 WHEN bus.backup_finish_date IS NULL OR bus.is_damaged = 1 THEN 1
						 ELSE 0
					 END AS is_failed
				FROM 
					msdb.dbo.backupmediafamily AS bmf
				INNER JOIN 
					msdb.dbo.backupset AS bus
				ON 
					bmf.media_set_id = bus.media_set_id 
				WHERE 
					bus.[type] = 'D'
					AND bus.backup_start_date  IS NOT NULL
					AND bus.backup_start_date BETWEEN @start_dt_tm AND @end_dt_tm
			) AS sfb
		)
		SELECT
			@exec_id AS [execution_id]
			,@server AS [server_name]
			,lfb.[database_name]
			,lfb.backup_start_date AS latest_full_backup_start_date
			,SUM(wfb.was_successful) AS full_backup_count_last_7_days
			,SUM(wfb.is_failed) AS failed_backup_count_last_7_days
			,GETDATE() AS created_dt_tm
		FROM
			last_weeks_backups AS lfb
		INNER JOIN
			last_weeks_backups AS wfb
		ON
			wfb.[database_name] = lfb.[database_name]
		WHERE
			lfb.backupset_index_desc = 1
		GROUP BY
			lfb.[database_name]
			,lfb.backup_start_date
		ORDER BY
			lfb.[database_name]
		--';


	END TRY
	BEGIN CATCH
		EXEC ISDB.[dbo].[Log_Try_Catch_Error_Information_w_Return] @parameters, @label, @out_error_id OUTPUT, @out_error_messge OUTPUT
		INSERT INTO ISDB.dbo.sql_status_execution_errors (execution_id, error_id) VALUES (@exec_id, @out_error_id)
		GOTO exit_point
	END CATCH


	SET @label = 'EXEC sp_executesql'
	BEGIN TRY

		--PRINT @databases_command

		INSERT INTO
			ISDB.dbo.sql_status_latest_full_backups_previous_7_days
		(
			execution_id
			,server_name
			,[database_name]
			,latest_full_backup_start_date
			,full_backup_count_last_7_days
			,failed_full_backup_count_last_7_days
			,created_dt_tm
		)
		EXEC sp_executesql @databases_command, @params
										  , @exec_id     = @exec_id
										  , @server      = @server
										  , @start_dt_tm = @start_dt_tm
										  , @end_dt_tm   = @end_dt_tm

	END TRY
	BEGIN CATCH
		EXEC ISDB.[dbo].[Log_Try_Catch_Error_Information_w_Return] @parameters, @label, @out_error_id OUTPUT, @out_error_messge OUTPUT
		INSERT INTO ISDB.dbo.sql_status_execution_errors (execution_id, error_id) VALUES (@exec_id, @out_error_id)
		GOTO exit_point
	END CATCH


exit_point:


    SET NOCOUNT OFF


