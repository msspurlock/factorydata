EXEC sp_updatestats;
