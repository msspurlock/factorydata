USE master;  
GO  
EXEC sp_configure 'show advanced option', '1';  
RECONFIGURE;  
EXEC sp_configure;  
GO

EXEC sp_configure 'Ad Hoc Distributed Queries', '1';
RECONFIGURE;  
GO

EXEC sp_configure 'backup checksum default', '1';
RECONFIGURE;  
GO

EXEC sp_configure 'backup compression default', '1';
RECONFIGURE;  
GO

EXEC sp_configure 'blocked process threshold (s)', '60';
RECONFIGURE;  
GO

EXEC sp_configure 'xp_cmdshell', '1';
RECONFIGURE;  
GO

EXEC sp_configure;  
GO
