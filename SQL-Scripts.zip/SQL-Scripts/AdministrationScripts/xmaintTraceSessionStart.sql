USE [ISDB]
GO

/****** Object:  StoredProcedure [dbo].[xmaintTraceSessionStop]    Script Date: 3/31/2017 12:59:37 PM ******/
DROP PROCEDURE [dbo].[xmaintTraceSessionStop]
GO

/****** Object:  StoredProcedure [dbo].[xmaintTraceSessionStop]    Script Date: 3/31/2017 12:59:37 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[xmaintTraceSessionStop] @traceId INT 
AS 
EXEC sp_trace_setstatus @traceId,0 
EXEC sp_trace_setstatus @traceId,2 


GO


