--Here are the queries to look up columns.


SELECT
    *
FROM
    sys.sysobjects
WHERE
    name = 'x837ClaimDetail'

SELECT
    *
FROM
    sys.syscolumns
WHERE
    id = 
    (
SELECT TOP 1
    id
FROM
    sys.sysobjects
WHERE
    name = 'x837ClaimDetail'
    )



SELECT
    *
FROM
    sys.sysobjects
WHERE
    name = 'xAuthsFlatFile'

SELECT
    *
FROM
    sys.syscolumns
WHERE
    id = 
    (
SELECT TOP 1
    id
FROM
    sys.sysobjects
WHERE
    name = 'xAuthsFlatFile'
    )
    AND name LIKE '%JobId%'


SELECT
    col.name
    ,obj.name AS [ObjectName]
    ,col.*
FROM
    sys.syscolumns AS col
INNER JOIN
    sys.objects AS obj
ON
    obj.object_id = col.id
WHERE
    col.name LIKE '%RefNbr%'
    AND obj.name LIKE '%claim%'