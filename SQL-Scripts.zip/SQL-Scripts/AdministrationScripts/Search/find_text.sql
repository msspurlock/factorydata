SELECT OBJECT_NAME(object_id), 
       OBJECT_DEFINITION(object_id)
FROM sys.procedures
WHERE OBJECT_DEFINITION(object_id) LIKE '%program%'
--AND OBJECT_NAME(object_id) LIKE 'xcdp%'

