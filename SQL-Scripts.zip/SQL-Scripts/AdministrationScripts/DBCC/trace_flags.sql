DBCC TRACESTATUS (-1);
GO
dbcc traceon (3023, -1) --enable trace for backup checksum
GO
DBCC TRACESTATUS (-1);
GO
dbcc traceoff (3023, -1) --enable trace for backup checksum
GO
DBCC TRACESTATUS (-1);
GO
