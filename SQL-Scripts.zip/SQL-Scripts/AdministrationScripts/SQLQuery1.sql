EXEC xp_cmdshell 'dir g:\mssql'
EXEC xp_cmdshell 'move g:\mssql\brt_trace_by_login_NIGHTINGALE_kentr_d20170331143936.trc \\server05\company\MHS\IT\SQLServer'
--'move g:\mssql\brt_trace_by_login_NIGHTINGALE_briant_d20170331131442.trc \\server05\company\MHS\IT\SQLServer'
--'del /Q g:\mssql\brt_trace_by_spid_130_d20170331120031.trc'
--'dir g:\mssql'
--'del /Q g:\mssql\brt_trace_by_spid_130_d20170331120031.trc'
--'dir c:\'
--'dir \\server05\company\MHS\IT\SQLServer'

--03/31/2017  02:41 PM         1,048,576 brt_trace_by_login_NIGHTINGALE_kentr_d20170331143936.trc