
/*
SELECT @@SPID

EXEC xmaintTraceMySessionStart @@SPID
--2
*/

/*
EXEC xmaintTraceLoginSessionsStart N'NIGHTINGALE\kentr'
-- 2
*/

SELECT * FROM ISDB.dbo.RefreshConfig

/*
EXEC xmaintTraceSessionStop 2
*/
