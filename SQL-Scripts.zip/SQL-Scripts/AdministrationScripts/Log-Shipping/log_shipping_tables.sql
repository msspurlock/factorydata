
SELECT
	*
FROM
	msdb.dbo.log_shipping_monitor_alert

SELECT
	*
FROM
	msdb.dbo.log_shipping_monitor_error_detail

SELECT
	*
FROM
	msdb.dbo.log_shipping_monitor_history_detail

SELECT
	*
FROM
	msdb.dbo.log_shipping_monitor_primary

SELECT
	*
FROM
	msdb.dbo.log_shipping_monitor_secondary

SELECT
	*
FROM
	msdb.dbo.log_shipping_primary_databases

SELECT
	*
FROM
	msdb.dbo.log_shipping_primary_secondaries

SELECT
	*
FROM
	msdb.dbo.log_shipping_secondary

SELECT
	*
FROM
	msdb.dbo.log_shipping_secondary_databases
