﻿#
# Name: ConfigureLogShipping.ps1
# Purpose: Configure log shipping for one or more databases
# Creator: Allan Hirt, SQLHA LLC
# Date: March 1, 2018
# Version: 1.0
# 
# This script is provided as is with no warranty. Use at your own risk.
# Always test before using in a production environment.  
#

#
# Primary folder name for the backups
# Modify $DriveLetter and $TopLevelBackupFolder
#
$DriveLetter = "V"
$PrimaryTopLevelBackupFolder = "MSSQL\Backups\Files"
$SecondaryTopLevelBackupFolder = "MSSQL\Backups\SSRS\Files"

#
# Source Instance
#
$PrimarySQLInstance = "LYNSQLC02\SSRS"
$PrimaryWindows = "LYNSQLC02"

#
# Instance to Restore the full and transaction log backups
#
$WarmStandby = "HQSQLDR01\SSRS"

#
# Load the list of databases
# Configure $FolderForXMLDBList and $DBListXMLFile
# Modify $FolderForXMLDBList and $DBListXMLFile
#
$FolderForXMLDBList = "W:\MSSQL\Backups\LSScripts1"
$DBListXMLFile = "DBsToRestoreLS.xml"
$FullXMLFilePath = $FolderForXMLDBList + '\' + $DBListXMLFile
[xml]$dbinfo = Get-Content $FullXMLFilePath

$separatorline = "---------------------------------------------------------------------"

foreach ($DB in $dbinfo.Databases.DBName) {
    $OutputText = "Creating log shipping for database " + $DB
    Write-Output $OutputText

    #
    # Set the path to the backups
    #
    $PrimaryBackupPath = $DriveLetter + ':\' + $PrimaryTopLevelBackupFolder + '\' + $DB
    # Modify this before excution to ensure it is the right path  
    $PrimaryUNC = '\\' + $PrimaryWindows + '\' + 'VBackups\Files\' + $DB

    #
    # Set up the database on the primary
    #
    $createprimary = "exec master.dbo.sp_add_log_shipping_primary_database @database = N'" + $DB + "'
    ,@backup_directory = N'" + $PrimaryBackupPath + "'
    ,@backup_share = N'" + $PrimaryUNC + "' 
    ,@backup_job_name = N'LS T-Log " + $DB + " Backup Job' 
    ,@backup_retention_period = 43200
    ,@backup_compression = 2
    ,@monitor_server = N'" + $WarmStandby + "' 
	,@monitor_server_security_mode = 1
    ,@backup_threshold = 60
    ,@threshold_alert_enabled = 1
    ,@history_retention_period = 5760
    ,@overwrite = 1 
    ,@ignoreremotemonitor = 1" 

    Write-Output $separatorline
    Write-Output $createprimary
    $executesql = Invoke-Sqlcmd -ServerInstance $PrimarySQLInstance -Query $createprimary

    #
    # Get the info about the primary needed later 
    #
    $primaryinfo = "SELECT primary_id, backup_job_id FROM msdb.dbo.log_shipping_primary_databases WHERE primary_database = '" + $DB + "'"
    $executesql = Invoke-Sqlcmd -ServerInstance $PrimarySQLInstance -Query $primaryinfo
   
    $primaryid = $executesql.primary_id
    $backupjobid = $executesql.backup_job_id

    $backupschedulename = $DB + " T-Log Backup Schedule"

    $addbackupjobschedule = "exec msdb.dbo.sp_add_schedule 
		@schedule_name =N'" + $backupschedulename + "' 
		,@enabled = 1 
		,@freq_type = 4 
		,@freq_interval = 1 
		,@freq_subday_type = 4 
		,@freq_subday_interval = 15 
		,@freq_recurrence_factor = 0 
		,@active_start_date = 20180216 
		,@active_end_date = 99991231 
		,@active_start_time = 0 
		,@active_end_time = 235900" 

    Write-Output $separatorline
    Write-Output $addbackupjobschedule
    $executesql = Invoke-Sqlcmd -ServerInstance $PrimarySQLInstance -Query $addbackupjobschedule

    #
    # Get the schedule info for the backup job
    #
    $backupscheduleinfo = "SELECT TOP 1 schedule_id, schedule_uid FROM msdb.dbo.sysschedules WHERE [name] = '" + $backupschedulename + "'"
    $executesql = Invoke-Sqlcmd -ServerInstance $PrimarySQLInstance -Query $backupscheduleinfo

    $backupscheduleid = $executesql.schedule_id
    $backupscheduleuid = $executesql.schedule_uid

    #
    # Attach the schedule to the backup job
    #
    $attachschedule = "exec msdb.dbo.sp_attach_schedule 
		@job_id = '" + $backupjobid + "'
		,@schedule_id = " + $backupscheduleid  

    Write-Output $separatorline
    Write-Output $attachschedule
    $executesql = Invoke-Sqlcmd -ServerInstance $PrimarySQLInstance -Query $attachschedule

    #
    # Enable the backup job on the primary
    #
    $enablebackupjob = "exec msdb.dbo.sp_update_job 
		@job_id = '" + $backupjobid + "' 
		,@enabled = 1"  

    Write-Output $separatorline
    Write-Output $enablebackupjob
    $executesql = Invoke-Sqlcmd -ServerInstance $PrimarySQLInstance -Query $enablebackupjob

    #
    # Configure the warm standby with info about the primary
    #
    $copyjob = "LS T-Log " + $DB + " Copy Backups for from " + $PrimaryWindows
    $restorejob = "LS T-Log " + $DB + " Restore"
    $StandbyBackupPath = $DriveLetter + ':\' + $SecondaryTopLevelBackupFolder + '\' + $DB

    $primaryrelationship = "exec master.dbo.sp_add_log_shipping_secondary_primary 
		@primary_server = N'" + $PrimarySQLInstance + "' 
		,@primary_database = N'" + $DB + "' 
		,@backup_source_directory = N'" + $PrimaryUNC + "' 
		,@backup_destination_directory = N'" + $StandbyBackupPath + "' 
		,@copy_job_name = N'" + $copyjob + "'
		,@restore_job_name = N'" + $restorejob + "' 
		,@file_retention_period = 43200 
		,@monitor_server = N'" + $WarmStandby + "' 
		,@monitor_server_security_mode = 1 
			,@overwrite = 1" 

    Write-Output $separatorline
    Write-Output $primaryrelationship
    $executesql = Invoke-Sqlcmd -ServerInstance $WarmStandby -Query $primaryrelationship

    #
    # Get the info about the secondary needed later 
    #
    $secondaryinfo = "SELECT copy_job_id, restore_job_id FROM msdb.dbo.log_shipping_secondary WHERE primary_database = '" + $DB + "'"
    $executesql = Invoke-Sqlcmd -ServerInstance $WarmStandby -Query $secondaryinfo 
   
    $copyjobid = $executesql.copy_job_id
    $restorejobid = $executesql.restore_job_id

    #
    # Set the copy schedule
    #
    $copyschedulename = $DB + " T-Log Copy Schedule"
   
    $addcopyjobschedule = "exec msdb.dbo.sp_add_schedule 
		@schedule_name =N'" + $copyschedulename + "' 
		,@enabled = 1 
		,@freq_type = 4 
		,@freq_interval = 1 
		,@freq_subday_type = 4 
		,@freq_subday_interval = 15 
		,@freq_recurrence_factor = 0 
		,@active_start_date = 20180216 
		,@active_end_date = 99991231 
		,@active_start_time = 0 
		,@active_end_time = 235900" 
    $executesql = Invoke-Sqlcmd -ServerInstance $WarmStandby -Query $addcopyjobschedule

    #
    # Get the schedule info for the copy job
    #
    Write-Output $copyschedulename
    $copyscheduleinfo = "SELECT TOP 1 schedule_id, schedule_uid FROM msdb.dbo.sysschedules WHERE [name] = '" + $copyschedulename + "'"
    Write-Output $copyscheduleinfo
    $executesql = Invoke-Sqlcmd -ServerInstance $WarmStandby -Query $copyscheduleinfo

    $copyscheduleid = $executesql.schedule_id
    $copyscheduleuid = $executesql.schedule_uid

    #
    # Attach the schedule to the copy job
    #
    $attachschedule = "exec msdb.dbo.sp_attach_schedule	@job_id = '" + $copyjobid + "', @schedule_id = " + $copyscheduleid  

    Write-Output $WarmStandby
    Write-Output $attachschedule

    $executesql = Invoke-Sqlcmd -ServerInstance $WarmStandby -Query $attachschedule

    #
    # Set the restore schedule
    #
    $restoreschedulename = $DB + " T-Log Restore Schedule"
   
    $addrestorejobschedule = "exec msdb.dbo.sp_add_schedule 
		@schedule_name =N'" + $restoreschedulename + "' 
		,@enabled = 1 
		,@freq_type = 4 
		,@freq_interval = 1 
		,@freq_subday_type = 4 
		,@freq_subday_interval = 15 
		,@freq_recurrence_factor = 0 
		,@active_start_date = 20180216 
		,@active_end_date = 99991231 
		,@active_start_time = 0 
		,@active_end_time = 235900"
    $executesql = Invoke-Sqlcmd -ServerInstance $WarmStandby -Query $addrestorejobschedule

    #
    # Get the schedule info for the restore job
    #
    $restorescheduleinfo = "SELECT schedule_id, schedule_uid FROM msdb.dbo.sysschedules WHERE [name] = '" + $restoreschedulename + "'"
    $executesql = Invoke-Sqlcmd -ServerInstance $WarmStandby -Query $restorescheduleinfo

    $restorescheduleid = $executesql.schedule_id
    $restorescheduleuid = $executesql.schedule_uid

    #
    # Attach the schedule to the restore job
    #
    $attachschedule = "exec msdb.dbo.sp_attach_schedule 
		@job_id = '" + $restorejobid + "'
		,@schedule_id = " + $restorescheduleid  
    $executesql = Invoke-Sqlcmd -ServerInstance $WarmStandby -Query $attachschedule

    #
    # Add the database to the warm standby
    #
    $adddbtostandby = "exec master.dbo.sp_add_log_shipping_secondary_database 
		@secondary_database = N'" + $DB +"' 
		,@primary_server = N'" + $PrimarySQLInstance + "' 
		,@primary_database = N'" + $DB + "' 
		,@restore_delay = 0 
		,@restore_mode = 0 
		,@disconnect_users	= 0 
		,@restore_threshold = 45   
		,@threshold_alert_enabled = 1 
		,@history_retention_period = 5760 
		,@overwrite = 1" 
    $executesql = Invoke-Sqlcmd -ServerInstance $WarmStandby -Query $adddbtostandby

    #
    # Enable the jobs on the warm standby
    #
    $enablecopyjob = "exec msdb.dbo.sp_update_job 
		@job_id = '" + $copyjobid + "' 
		,@enabled = 1"  
    $executesql = Invoke-Sqlcmd -ServerInstance $WarmStandby -Query $enablecopyjob

    $enablerestorejob = "exec msdb.dbo.sp_update_job 
		@job_id = '" + $restorejobid + "' 
		,@enabled = 1"  
    $executesql = Invoke-Sqlcmd -ServerInstance $WarmStandby -Query $enablerestorejob

    #
    # Tell the primary about how it relates to the secondary
    #
    
    $primaryinfo = "exec master.dbo.sp_add_log_shipping_primary_secondary 
    	@primary_database = N'" + $DB + "' 
		,@secondary_server = N'" + $WarmStandby + "' 
		,@secondary_database = N'" + $DB + "' 
		,@overwrite = 1" 
    $executesql = Invoke-Sqlcmd -ServerInstance $PrimarySQLInstance -Query $primaryinfo

    #
    # Configure the monitor
    #
    $configurelsmonitor = "EXEC msdb.dbo.sp_processlogshippingmonitorprimary 
		@mode = 1 
		,@primary_id = N'' 
		,@primary_server = N'" + $PrimarySQLInstance + "' 
		,@monitor_server = N'" + $WarmStandby + "' 
		,@monitor_server_security_mode = 1 
		,@primary_database = N'" + $DB + "' 
		,@backup_threshold = 60 
		,@threshold_alert = 14420 
		,@threshold_alert_enabled = 1 
		,@history_retention_period = 5760" 
    $executesql = Invoke-Sqlcmd -ServerInstance $PrimarySQLInstance -Query $primaryinfo

    Write-Output ""
}