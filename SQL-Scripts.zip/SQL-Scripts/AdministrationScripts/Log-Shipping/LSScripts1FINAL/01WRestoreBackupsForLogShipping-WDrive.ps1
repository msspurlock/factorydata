#
# Name: RestoreBackupsForLogShipping.ps1
# Purpose: One time use script for initializing a warm standby where all of the full and t-log backups are copied to that server
# Creator: Allan Hirt, SQLHA LLC
# Date: February 16, 2018
# Version: 1.0
# 
# This script is provided as is with no warranty. Use at your own risk.
# Always test before using in a production environment.  
#

#
# Primary folder name for the backups
#
$TopLevelBackupFolder = "W:\MSSQL\Backups\Files"

#
# Define the extensions for SQL Server Backups
# Change only if using non-default values
#
$FullBackupFileExtension = ".bak"
$TlogBackupFileExtension = ".trn"

#
# Instance to Restore the full and transaction log backups
#
$Instance = "HQSQLDR01"

#
# Load the list of databases
# Configure $FolderForXMLDBList and $DBListXMLFile
#
$FolderForXMLDBList = "W:\MSSQL\Backups\LSScripts1"
$DBListXMLFile = "DBsToProcess.xml"
$FullXMLFilePath = $FolderForXMLDBList + '\' + $DBListXMLFile
[xml]$dbinfo = Get-Content $FullXMLFilePath
#$dbinfo

foreach ($DB in $dbinfo.Databases.DBName){
    #$DB
    #Write-Host "$($DB)"
    
    #
    # Set the path to the backups
    #
    $BackupPath = $TopLevelBackupFolder + '\' + $DB

    #
    # Full Backup
    #

    #
    # Get the full backup file name with path
    # This assumes only one full backup (and its subsequent transaction log files)
    #
    $FullBackupFile = (Get-ChildItem -Path $BackupPath | where {$_.Extension -eq '.bak'}).FullName

    # 
    # Restore the full backup
    # This assumes the same path exists as the source instance
    #
    $OutputText = 'Restoring the full backup file ' + $FullBackupFile + ' for database' + $DB + ' WITH NORECOVERY.' 
    Write-Output $OutputText

   	Restore-SqlDatabase -ServerInstance $Instance -Database $DB -BackupFile $FullBackupFile -RestoreAction Database -NoRecovery

        #
    # Restore the transaction log backup files
    #
    foreach ($tlog in (Get-ChildItem -Path $BackupPath | where {$_.Extension -eq $TlogBackupFileExtension} | sort LastWriteTimeUtc)) {
        #
        # Set the name of the t-log backup including the path
        #
        $TlogBackupFile = $tlog.FullName 

        #
        # Restore the t-log backup
        # This assumes same path
        # To check if there are no errors, look at SQL Server's log
        #
        #
        $OutputText = 'Restoring the transaction log backup file ' + $TlogBackupFile + ' for database ' + $DB +  ' WITH NORECOVERY.'
        Write-Output $OutputText
         
        Restore-SqlDatabase -ServerInstance $Instance -Database $DB -BackupFile $TlogBackupFile -RestoreAction Log -NoRecovery
        }
    Write-Output ""
}
