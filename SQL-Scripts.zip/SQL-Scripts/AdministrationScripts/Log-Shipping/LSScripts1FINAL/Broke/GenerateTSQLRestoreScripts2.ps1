#
# Name: GenerateTSQLRestoreScripts.ps1
# Purpose: One time use script for creating the Transact-SQL restore files for a warm standby where all of the full and t-log backups are copied to that server
# Creator: Allan Hirt, SQLHA LLC
# Date: February 16, 2018
# Version: 1.0
# 
# This script is provided as is with no warranty. Use at your own risk.
# Always test before using in a production environment.  
#

#
# Primary folder name for the backups
#
$TopLevelBackupFolder = "W:\MSSQL\Backups\Files"

#
# Define the extensions for SQL Server Backups
# Change only if using non-default values
#
$FullBackupFileExtension = ".bak"
$TlogBackupFileExtension = ".trn"

#
# Load the list of databases
# Configure $FolderForXMLDBList and $DBListXMLFile
#
$FolderForXMLDBList = "W:\MSSQL\Backups\LSScripts1"
$DBListXMLFile = "DBsToRestore.xml"

$FullXMLFilePath = $FolderForXMLDBList + '\' + $DBListXMLFile
[xml]$dbinfo = (Get-Content $FullXMLFilePath)

foreach ($DB in $dbinfo.Databases.DBName) {
    $DB
    ##$OutputText = 'Creating the T-SQL restore file for database ' + $DB
    ##Write-Output $OutputText

    # Set the path to the backups
    #
    $BackupPath = $TopLevelBackupFolder + '\' + $DB

    #
    # Name of the T-SQL Restore File with Full Path
    #
    $TSQLRestoreFile = $BackupPath + '\' + 'Restore' + $DB + '.sql'

    #
    # Full Backup
    #

    #
    # Get the full backup file name with path
    # This assumes only one full backup (and its subsequent transaction log files)
    #
    $FullBackupFile = (Get-ChildItem -Path $BackupPath | where {$_.Extension -eq '.bak'}).FullName

    #
    # Create command to restore the full backup
    #
    $RestoreFullCommand = 'RESTORE DATABASE ' + $DB + ' FROM DISK = ' + "'" + $FullBackupFile + "'" + ' WITH NORECOVERY;'

    #
    # Create T-SQL File and add the command to restore the full backup
    #
    Add-Content -Path $TSQLRestoreFile -Value $RestoreFullCommand   
    Add-Content -Path $TSQLRestoreFile -Value "GO"
    Add-Content -Path $TSQLRestoreFile -Value ""

    #
    # Transaction log backup files
    # Files are sorted by the last time (in UTC) it was written to at the source
    # This time is consistent whenever a file is copied 
    # This also ensures the restores will happen in the order of the t-log backups
    # It will not account for any LSN issues
    #
    foreach ($tlog in (Get-ChildItem -Path $BackupPath | where {$_.Extension -eq $TlogBackupFileExtension} | sort LastWriteTimeUtc)) {
        #
        # Get the name of the transaction log with its path
        #
        $TlogBackupFile = $tlog.FullName 

        #
        # Create command to restore the full backup  
        #
        $RestoreTlogCommand = 'RESTORE LOG ' + $DB + ' FROM DISK = ' + "'" + $TlogBackupFile + "'" + ' WITH NORECOVERY;'

        #
        # Add the command to the existing restore file
        #
        Add-Content -Path $TSQLRestoreFile -Value $RestoreTlogCommand   
        Add-Content -Path $TSQLRestoreFile -Value "GO"
        Add-Content -Path $TSQLRestoreFile -Value ""        
    }
}