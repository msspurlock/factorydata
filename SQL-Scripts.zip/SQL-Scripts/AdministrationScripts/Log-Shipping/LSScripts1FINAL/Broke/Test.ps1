﻿ $DB = "Allan"

 $createprimary = "exec master.dbo.sp_add_log_shipping_primary_database @database = N'" + $DB + "'
    ,@backup_directory = N'" + $PrimaryBackupPath + "'
    ,@backup_share = N'" + $PrimaryUNC + "' 
    ,@backup_job_name = N'LS T-Log " + $DB + " Backup Job' 
    ,@backup_retention_period = 4320
    ,@backup_compression = 2
    ,@monitor_server = N'" + $WarmStandby + "' 
	,@monitor_server_security_mode = 1
    ,@backup_threshold = 60
    ,@threshold_alert_enabled = 1
    ,@history_retention_period = 5760
    ,@overwrite = 1 
    ,@ignoreremotemonitor = 1" 


    $createprimary