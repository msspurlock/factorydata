use msdb

select * from log_shipping_monitor_history_detail where message not like '%delet%'
select last_restored_file, * from log_shipping_monitor_secondary
--WHERE last_restored_file IS NULL
ORDER BY secondary_database
select * from log_shipping_monitor_primary


/*
use master
go

RESTORE LOG CDNVAPP FROM DISK = 'W:\MSSQL\Backups\Files\CDNVAPP\CDNVAPP_backup_2018_03_02_000502_5157709.trn' WITH NORECOVERY
*/




