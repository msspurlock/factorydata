SELECT
    m.physical_device_name
   ,b.backup_start_date
   ,b.backup_finish_date
FROM
    msdb.dbo.backupset AS b
JOIN
    msdb.dbo.backupmediafamily AS m
ON 
	b.media_set_id = m.media_set_id
WHERE 
	database_name = 'sugarcrm_db' 
ORDER BY
    b.backup_finish_date DESC;
