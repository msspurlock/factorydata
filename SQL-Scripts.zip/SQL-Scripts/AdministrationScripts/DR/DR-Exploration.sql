
SELECT TOP 1
	*
FROM
	msdb.dbo.backupmediaset AS m
ORDER BY
	m.media_set_id DESC

SELECT TOP 1
	s.server_name
	,s.database_name
	,s.backup_start_date
	,s.backup_finish_date
	,*
FROM
	msdb.dbo.backupset AS s
ORDER BY
	s.backup_set_id DESC

SELECT TOP 1
	*
FROM
	msdb.dbo.backupfile AS f
ORDER BY
	f.backup_set_id DESC
	