
DECLARE @server_name   NVARCHAR(128)
DECLARE @database_name NVARCHAR(128)
--SELECT @@SERVERNAME
--SELECT DB_NAME
SET @server_name = N'LYNSQLC01'
SET @database_name = N'sugarcrm_db'


DECLARE @command NVARCHAR(MAX)


SET @command = N'
SELECT TOP 10
	s.server_name
	,s.database_name
	,s.name
	,s.backup_start_date
	,s.backup_finish_date
	,m.physical_device_name
	,s.*
	,m.*
FROM
	' + QUOTENAME(@server_name) + '.msdb.dbo.backupset AS s
INNER JOIN
	' + QUOTENAME(@server_name) + '.msdb.dbo.backupmediafamily AS m
ON
	m.media_set_id = s.media_set_id
WHERE
	s.database_name = @database_name
ORDER BY
	s.backup_start_date DESC
'

/*
sp_executesql [ @stmt = ] statement
[ 
  { , [ @params = ] N'@parameter_name data_type [ OUT | OUTPUT ][ ,...n ]' } 
     { , [ @param1 = ] 'value1' [ ,...n ] }
]
*/

EXEC sp_executesql @command, N'@database_name NVARCHAR(128)', @database_name


