
-- MOVING SYSTEM DB FILES
-- SET AND EXECUTE ALTER
-- STOP SERVICE
-- MOVE FILES
-- START SERVICE
ALTER DATABASE model MODIFY FILE ( NAME = modellog , FILENAME = 'F:\MSSQL\Training\Logs\modellog.ldf' )  
ALTER DATABASE msdb MODIFY FILE ( NAME = MSDBLog , FILENAME = 'F:\MSSQL\Training\Logs\MSDBLog.ldf' )  

SELECT name, physical_name AS CurrentLocation, state_desc  
FROM sys.master_files  
WHERE database_id = DB_ID('model');  
GO
SELECT name, physical_name AS CurrentLocation, state_desc  
FROM sys.master_files  
WHERE database_id = DB_ID('msdb');  
GO

-- MASTER DB
/*
https://docs.microsoft.com/en-us/sql/relational-databases/databases/move-system-databases?view=sql-server-2017
*/
/*
SELECT name, physical_name AS CurrentLocation, state_desc  
FROM sys.master_files  
WHERE database_id = DB_ID('master');  
GO
*/  