DECLARE @DatabaseName SYSNAME

SET @DatabaseName = DB_NAME(DB_ID())
 --INSERT @BlockingProcesses
 --      (
 --          DatabaseName,
 --          BlockedSPID,
 --          BlockedQuery,
 --          BlockedResource,
 --          BlockingSPID,
 --          BlockingSQL,
 --          DATETIME
 --      )
       
   -- get  the blocked processes and the process that is blocking

   SELECT 
       DB_NAME(Blocked.database_id)                    AS DatabaseName,
       Blocked.Session_ID                              AS BlockedSPID,
       Blocked_SQL.TEXT                                AS BlockedQuery,
       Waits.wait_type                                 AS BlockedResource,
       Blocking.Session_ID                             AS BlockingSPID,
       Blocking_SQL.TEXT                               AS BlockingSQL,
       GETDATE()                                       AS DATETIME
   FROM sys.dm_exec_connections AS Blocking 
   INNER JOIN sys.dm_exec_requests AS Blocked
       ON Blocked.Blocking_Session_ID = Blocking.Session_ID
   INNER JOIN sys.dm_os_waiting_tasks AS Waits 
       ON waits.Session_ID = Blocked.Session_ID
   CROSS APPLY sys.dm_exec_sql_text(Blocking.most_recent_sql_handle) AS Blocking_SQL
   CROSS APPLY sys.dm_exec_sql_text(Blocked.sql_handle) AS Blocked_SQL
   WHERE Blocked.database_id = ISNULL(DB_ID(@DatabaseName),Blocked.database_id) 