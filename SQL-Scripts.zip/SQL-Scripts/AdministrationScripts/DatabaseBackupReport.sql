USE [ISDB]
GO

/****** Object:  StoredProcedure [dbo].[DatabaseBackupReport]    Script Date: 6/1/2017 11:31:12 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DatabaseBackupReport]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DatabaseBackupReport]
GO

/****** Object:  StoredProcedure [dbo].[DatabaseBackupReport]    Script Date: 6/1/2017 11:31:12 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DatabaseBackupReport]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[DatabaseBackupReport] AS' 
END
GO

-- =============================================
-- Author:		John Stewart
-- Create date: 01/06/2011
-- Description:	Compile a report of latest backup data
-- =============================================
ALTER PROCEDURE [dbo].[DatabaseBackupReport]

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
--	SET NOCOUNT ON;

SELECT cast(d.name as varchar(25)) as [DBname]
, [hoursSinceFull] = max(isnull(datediff(hour,b.backup_start_date,getdate()),-1)) 
, [hoursSinceDiff] = max(isnull(datediff(hour,bi.backup_start_date,getdate()),-1))
,b.backup_start_date as LastFullDate
,bi.backup_start_date LastLogDate
FROM [master].[sys].[databases] d with (nolock)
LEFT JOIN [msdb]..[backupset] b  with (nolock) on d.name = b.database_name 
and b.backup_start_date = (select max(backup_start_date)
from [msdb]..[backupset] b2
where b.database_name = b2.database_name and b2.type = 'D'  and b2.user_name <> 'NT AUTHORITY\SYSTEM')--and b2.user_name like '%sqlexec%')
LEFT JOIN [msdb]..[backupset] bi  with (nolock) on d.name = bi.database_name
and bi.backup_start_date = (select max(backup_start_date)
from [msdb]..[backupset] b3
where bi.database_name = b3.database_name and b3.type = 'L')
where 1=1
--and d.name not in  ('tempdb')
and d.state = 0 
and d.source_database_id is null  
group by d.name, b.backup_start_date, bi.backup_start_date

END

GO


