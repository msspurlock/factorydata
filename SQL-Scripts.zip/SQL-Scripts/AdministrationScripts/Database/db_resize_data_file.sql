




USE master;
GO
ALTER DATABASE EVV
MODIFY FILE
    (NAME = EVV,
    SIZE = 10368);
GO