ALTER DATABASE [CRM2016SAND_MSCRM]
SET SINGLE_USER WITH
ROLLBACK AFTER 60 --this will give your current connections 60 seconds to complete
