/*
sp_helpdb 'ISDB';
GO

sp_helpdb 'CDMSCRM_MSCRM';
GO

sp_helpdb 'CRM2016SAND_MSCRM';
GO

sp_helpdb 'MSCRM_CONFIG';
GO

sp_helpdb 'PLAY_MSCRM';
GO
*/

/*
SELECT DB_NAME(database_id) AS DatabaseName, name AS LogicalFileName, physical_name AS PhysicalFileName 
FROM sys.master_files AS mf
*/

sp_helpdb 'EVV';
GO