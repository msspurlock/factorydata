

DECLARE @i     INT
DECLARE @power INT

SET @power = 0

WHILE @power <= 30
BEGIN

	SET @i = POWER( 2.0, @power)

	SELECT
		@power AS [Power]
		,@i    AS [Value]

	SET @power += 1

END

