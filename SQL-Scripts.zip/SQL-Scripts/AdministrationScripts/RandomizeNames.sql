USE [test]
go

return

declare @db varchar(50)
	,@servername varchar(50)

select @db = 'test', @servername = 'LYNSQLHV01'

select @db, @servername

if exists (select * from slsystem.dbo.company where databasename = db_name()) or db_name() <> @db or @servername <> @servername
begin
print 'PRODUCTION DATABASE'
end
else
begin

 
if db_name() = 'test'
begin
print 'doing it....'
begin tran
--Have to loop through the table you want to update because UDF doesn't call itself on each new row.
--Set each unique empid to some random name
declare @e_empid varchar(15)
declare @randnum varchar(1)
declare e_cursor cursor for 
select distinct left(empid,7) from employee
open e_cursor

FETCH NEXT FROM e_cursor 
INTO @e_empid

WHILE @@FETCH_STATUS = 0
	begin
	select @randnum = case when isdb.dbo.randnumber() <.5 then 'M' else 'F' end	
	update w2 set
		w2.namefirst = rtrim(rn.firstname)
		,w2.namelast = rtrim(rn.lastname)
	from w2empname w2, isdb.dbo.randomname(@randnum) rn
	where left(w2.empid,7) = @e_empid
	
	FETCH NEXT FROM e_cursor 
	INTO @e_empid
end
close e_cursor
DEALLOCATE e_cursor

--update employee table fields to previously set random name
update e set 
	e.name = rtrim(w2.namelast)+ '~' + rtrim(w2.namefirst)
from employee e, w2empname w2
where e.empid = w2.empid




--Update the customer stuff
declare @c_custid varchar(15)
--declare @randnum varchar(1)
declare c_cursor cursor for 
select custid from xcustex
open c_cursor

FETCH NEXT FROM c_cursor 
INTO @c_custid

WHILE @@FETCH_STATUS = 0
	begin
	select @randnum = case when isdb.dbo.randnumber() <.5 then 'M' else 'F' end	
	update cx set
		cx.fstname = rtrim(rn.firstname)
		,cx.lstname = rtrim(rn.lastname)
	from xcustex cx, isdb.dbo.randomname(@randnum) rn
	where custid = @c_custid
	
	FETCH NEXT FROM c_cursor 
	INTO @c_custid
end
close c_cursor
DEALLOCATE c_cursor

--Update EIN holder stuff
declare @EINID varchar(15)
declare cEIN cursor for select distinct einid from xeinholder
open cEIN

fetch next from cEIN into @EINID
while @@fetch_status = 0
begin
	select @randnum = case when isdb.dbo.randnumber() < .5 then 'M' else 'F' end
	update eh
	set eh.namefirst = rtrim(rn.firstname)
		,eh.namelast = rtrim(rn.lastname)
	from xeinholder eh, isdb.dbo.randomname(@randnum) rn
	where einid = @einid

	fetch next from cein into @einid
end
close cein
deallocate cein

--update customer table and dob address etc
update c set 
	c.name = rtrim(cx.lstname) + ', ' + rtrim(cx.fstname)
from customer c, xcustex cx
where c.custid = cx.custid

update customer set 
	addr1 = '607 SW Higgins'
	,state = 'MT'
	,zip = '59803'
	,city = 'Missoula'
	,phone = '406-532-1900'

update customer set
	billaddr1 = addr1
	,billstate = state
	,billzip = zip
	,billphone = phone
	,billcity = city
	,fax = ''
	,emailaddr = ''
	,billname = name


update xcustex set
	dob = '1/1/1960'
	,ssn = case when ssn = '' then '' else left(cast(cast(rand(ssn) * 1000000000 as int) as varchar(9)) + '000000000',9) end
	,billemail = ''

update employee set
	addr1 = '607 SW Higgins'
	,state = 'MT'
	,zip = '59803'
	,city = 'Missoula'
	,birthdate = '1/1/1960'
	,phone = '406-532-1900'
	,ssn = left(cast(cast(rand(ssn) * 1000000000 as int) as varchar(9)) + '000000000',9)

update ex
set mailaddr1 = e.addr1
	,mailstate = e.state
	,mailzip = e.zip
	,mailcity = e.city
	,ecphone1 = ''
	,ecphone2 = ''
	,drvlicnum = ''
	,drvlicstate = ''
	,email = ''
from xemployeeex ex
inner join employee e on ex.empid = e.empid

update xeinholder set
	addr1 = '607 SW Higgins'
	,state = 'MT'
	,zip = '59803'
	,city = 'Missoula'
	,county = 'Missoula'
	,dob = '1/1/1900'
	,EIN = '99-9999999'
	,suta = '99-999999'
	,stateholding = '99-9999999'
	,phone = '5555555555'
	,ssn = case when ssn = '' then '' else left(cast(cast(rand(ssn) * 1000000000 as int) as varchar(9)) + '000000000',9) end
	

--erase comments from audit table
update xservicelog_audit set comment = '', username = ''

--newer changes
update customer set billname = name,cardnbr = '',cardhldrname = '',cardexpdate = '1/1/1900',cardtype = '',noteid = 0, addr2='', billaddr2 = ''
update xemployeeex set phone2 = '', ecname = '', county = '', MailCounty  = '', MailAddr2 = ''
update xcustex set billcounty = '', county = '', billemail = ''
update employee set emailaddr = '',noteid = 0,strtdate = '1/1/1960', addr2 = ''
delete from soaddress
delete from address
delete from poaddress
delete from smsoaddress





--Set dddepositor 
update dd set 
	bankacct00 = case when bankacct00 <> '' then '12345678' else '' end
	,bankacct01 = case when bankacct01 <> '' then '12345678' else '' end
	,bankacct02 = case when bankacct02 <> '' then '12345678' else '' end
	,bankacct03 = case when bankacct03 <> '' then '12345678' else '' end
	,bankacct04 = case when bankacct04 <> '' then '12345678' else '' end
	,bankacct05 = case when bankacct05 <> '' then '12345678' else '' end
	,banktransit00 =  case when banktransit00 <> '' then '123456789' else '' end
	,banktransit01 =  case when banktransit01 <> '' then '123456789' else '' end
	,banktransit02 =  case when banktransit02 <> '' then '123456789' else '' end
	,banktransit03 =  case when banktransit03 <> '' then '123456789' else '' end
	,banktransit04 =  case when banktransit04 <> '' then '123456789' else '' end
	,banktransit05 =  case when banktransit05 <> '' then '123456789' else '' end
from dddepositor dd

--update vendor
update v
set addr1 = '607 SW Higgins'
	,addr2 = ''
	,city = 'Missoula'
	,state = 'MT'
	,zip = '59803'
	,emailaddr = ''
	,remitaddr1 = '607 SW Higgins'
	,remitaddr2 = ''
	,remitcity = 'Missoula'
	,remitstate = 'MT'
	,remitzip = '59803'
	,phone = '4065321900'
	,remitphone = '4065321900'
	,fax = '4065321900'
	,remitfax = '4065321900'
	,TIN = '99-9999999'
from vendor v

update v
set accountnumber = '', contactnamefirst = '', ContactNameLast = '', contactnamemiddle = ''
from xvendorex v



delete from xWrkTaxAZ_UC_018Wages
delete from xWrkTaxID_WageReport
delete from xwrktaxcalc
delete from w2federal
delete from W2StateLocal
delete from WrkW2Letter
delete from wrkw2form
delete from wrkSUTAD
delete from xwrkTaxMO_SUTA_Employee
delete from xwrkTaxTX_SUTA_Employee
delete from xwrkTaxFed
delete from xwrkTaxFICA
delete from xwrkTaxFL_SUTA_Employee
delete from xwrkTaxFL_SUTA_Employer
delete from xwrktaxcalc_II
delete from xWrkTaxAZ_A1_QRT
delete from xWrkTaxAZ_UC_018Totals
delete from xWrkTaxAZ_UC_018Wages
delete from xwrkTaxCO_SUTA_Employee
delete from xwrkTaxCO_SUTA_Employer
delete from xWrkTaxID_967
delete from xWrkTaxID_TaxReport
delete from xWrkTaxID_WageReport
delete from xWrkTaxIRS940R
delete from xWrkTaxIRS941R
delete from xWrkTaxIRS941B
delete from xWrkTaxMEDI
delete from xwrkTaxMO_STATE_Employer
delete from xwrkTaxMO_SUTA_Employee
delete from xwrkTaxMO_SUTA_Employer
delete from xwrkTaxNM_SUTA_Employee
delete from xwrkTaxNM_SUTA_Employer
delete from xwrkTaxTX_SUTA_Employer
delete from xwrkTaxTX_SUTA_Employee
delete from xwrkTaxWI_SUTA_Employee
delete from xwrkTaxWI_SUTA_Employer
delete from xWrkTaxWI_WT6
delete from xWrkTaxWI_WT7













--







--select * from smemp

--if object_id('dbo.xacumenemployees') is not null drop table dbo.xacumenemployees
--if object_id('dbo.xacumentclients') is not null drop table dbo.xacumentclients
--if object_id('dbo.xAcumenClientEmployee') is not null drop table dbo.xAcumenClientEmployee


if exists (select * from slsystem.dbo.company where databasename = db_name())
begin
print 'rollback'
rollback tran
end
else
begin
print 'commit'
commit tran
end 

end
end




--select c.name, o.name from sys.columns c
--inner join sys.objects o on c.object_id = o.object_id
--where c.name like '%ssn%'
--and o.type = 'u'
--and c.name not like  '%accessnbr%'
--and c.name <> 'fieldclassname'
--and c.name <> 'faxaccessnumber'
--and c.name <> 'ssnoteid'
--and c.name <> 'ssnreq'
--
--select * from smemp


--select e.name, e2.name,e.ssn, e2.ssn,e.addr1,e.birthdate,e2.birthdate,e.strtdate,e2.strtdate from employee e
--inner join cdidapp..employee e2 on e.empid = e2.empid


--select e.name, e2.name,e3.ssn, e4.ssn,e.addr1,e.billname,e2.billname,e3.dob,e4.dob
--,e3.billphone2
--,e4.billphone2
--from customer e
--inner join cdidapp..customer e2 on e.custid = e2.custid
--inner join xcustex e3 on e.custid = e3.custid
--inner join cdidapp..xcustex e4 on e.custid = e4.custid


--select e.einid,e.namefirst, e2.namefirst,e.ssn, e2.ssn,e.addr1,e.ein,e.suta,e.stateholding from xeinholder e
--inner join cdidapp..xeinholder e2 on e.einid = e2.einid




--select * from DDDepositor

--select * from vendor
--select * from xvendorex

select * from xcustex
select * from customer
select * from employee
select * from xemployeeex
select * from w2empname
select * from xeinholder
select namefirst,namelast,(select name from employee where empid = w2empname.empid) from w2empname

--select * from soaddress

--select * from address

dbcc opentran












/*
use test
go


declare @tname varchar(100)
,@sql varchar(500)

declare c1 cursor for select name from sys.objects where type = 'u' and name like '%tax%' order by name


open c1

fetch next from c1 into @tname

while @@fetch_status = 0
begin
select @sql = 'select ''' + @tname + ''',* from ' + @tname
print @sql
exec (@sql)

fetch next from c1 into @tname
end


close c1
deallocate c1
*/