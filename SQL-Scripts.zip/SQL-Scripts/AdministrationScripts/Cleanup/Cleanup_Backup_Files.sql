EXEC xp_cmdshell 'Dir X:\MSSQL\Backup\Files\CDAKAPP'


/*
EXECUTE master.dbo.xp_delete_file 0,N'X:\MSSQL\Backup\Files',N'BAK',N'2017-04-23T11:57:42',1
EXECUTE master.dbo.xp_delete_file 0,N'X:\MSSQL\Backup\Files',N'BAK',N'2017-05-01T00:00:00',1
*/