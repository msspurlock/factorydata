
SELECT TOP 5
    *
FROM
    msdb.dbo.sysmail_mailitems
ORDER BY
    send_request_date ASC


    -------------------------------------------------------------------------------------------------
    -- BEGIN - SYSMAIL_MAILITEMS CLEANUP
    -------------------------------------------------------------------------------------------------
    DECLARE @mail_items_oldest_dt DATETIME;

    SET @mail_items_oldest_dt = CONVERT(DATETIME, CONVERT(DATE, DATEADD(dd, -160, GETDATE())))

    DECLARE @smic_start_dt_tm     DATETIME;
    DECLARE @smic_end_dt_tm       DATETIME;
    DECLARE @smic_elapsed_ms      INT;

    SET @smic_start_dt_tm = GETDATE();

    DECLARE @smic_record_count_pre INT;

    SELECT 
	   @smic_record_count_pre = COUNT(*) 
    FROM 
	   msdb.dbo.sysmail_mailitems


    DECLARE @item_to_delete_count INT;

    SELECT
	   @item_to_delete_count = COUNT(*)
    FROM 
	   msdb.dbo.sysmail_mailitems
    WHERE
	   send_request_date < @mail_items_oldest_dt


    DECLARE @smic_status INT;

    EXEC @smic_status = msdb.dbo.sysmail_delete_mailitems_sp @sent_before=@mail_items_oldest_dt;



    DECLARE @smic_record_count_post INT;

    SELECT 
	   @smic_record_count_post = COUNT(*) 
    FROM 
	   msdb.dbo.sysmail_mailitems

    SET @smic_end_dt_tm = GETDATE();
    SET @smic_elapsed_ms = DATEDIFF(MILLISECOND, @smic_start_dt_tm, @smic_end_dt_tm);



    DECLARE @item_not_deleted_count INT;

    SELECT
	   @item_not_deleted_count = COUNT(*)
    FROM 
	   msdb.dbo.sysmail_mailitems
    WHERE
	   send_request_date < @mail_items_oldest_dt


    SELECT
	   @mail_items_oldest_dt AS [Sent Before Date]
	   ,@smic_record_count_pre AS [Pre Delete Count]
	   ,@smic_record_count_post AS [Post Delete Count]
	   ,@smic_record_count_pre - @smic_record_count_post AS [Deleted Count]

	   ,@item_to_delete_count AS [Expected Delete Count]
	   ,@item_not_deleted_count AS [Not Deleted Count]

    -------------------------------------------------------------------------------------------------
    -- END - SYSMAIL_MAILITEMS CLEANUP
    -------------------------------------------------------------------------------------------------


SELECT TOP 5
    *
FROM
    msdb.dbo.sysmail_mailitems
ORDER BY
    send_request_date ASC


exit_point: