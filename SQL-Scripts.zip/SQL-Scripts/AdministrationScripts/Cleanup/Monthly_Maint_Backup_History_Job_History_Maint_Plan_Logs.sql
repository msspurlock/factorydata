USE msdb;
GO

DECLARE @DaysToKeepHistory DATETIME;

SET @DaysToKeepHistory = CONVERT(VARCHAR(10), DATEADD(dd, -183, GETDATE()), 101);

--SELECT @DaysToKeepHistory = '1/01/2017';

SELECT MIN(backup_start_date) ,MIN(backup_finish_date) FROM backupset;

--SELECT @DaysToKeepHistory;

----To speed up the backup history deletion I created 3 indexes:
CREATE NONCLUSTERED INDEX [IX_backupset_database_name_backup_set_id]
    ON [dbo].[backupset] ([database_name])
    INCLUDE ([backup_set_id]);

CREATE NONCLUSTERED INDEX [IX_backupset_database_name_media_set_id]
    ON [dbo].[backupset] ([database_name])
    INCLUDE ([media_set_id]);

CREATE NONCLUSTERED INDEX [_ped_backupset_media_set_id]
    ON [dbo].[backupset] ([media_set_id]);


DECLARE @dbh_status INT

EXEC @dbh_status = sp_delete_backuphistory @DaysToKeepHistory;
--GO 

DROP INDEX [IX_backupset_database_name_backup_set_id]
    ON [dbo].[backupset]
    WITH
    (   ONLINE = OFF);

DROP INDEX [IX_backupset_database_name_media_set_id]
    ON [dbo].[backupset]
    WITH
    (   ONLINE = OFF);

DROP INDEX [_ped_backupset_media_set_id]
    ON [dbo].[backupset]
    WITH
    (   ONLINE = OFF);
--GO 


SELECT MIN(backup_start_date) ,MIN(backup_finish_date) FROM backupset;
--
--select * from sysjobhistory order by run_date
SELECT COUNT(*) FROM sysjobhistory;

DECLARE @pjh_status INT

EXEC @pjh_status = sp_purge_jobhistory NULL, NULL, @DaysToKeepHistory;

--select * from sysjobhistory
SELECT COUNT(*) FROM sysjobhistory;

--select * from sysmaintplan_log order by start_time
--select * from sysmaintplan_logdetail

SELECT COUNT(*) FROM sysmaintplan_log;
SELECT COUNT(*) FROM sysmaintplan_logdetail;

DECLARE @mpdl_status INT

EXEC @mpdl_status = sp_maintplan_delete_log NULL, NULL, @DaysToKeepHistory;

--select * from sysmaintplan_log order by start_time
--select * from sysmaintplan_logdetail

SELECT COUNT(*) FROM sysmaintplan_log;
SELECT COUNT(*) FROM sysmaintplan_logdetail;

--CHECK SIZES OF TEMPDB FILES!
--CHECK SIZE OF REPORTSERVERTEMPDB LOG FILE - KEEP IT AT 500 MB
