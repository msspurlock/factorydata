USE [ISDB]
GO

/****** Object:  UserDefinedFunction [dbo].[ToTimeSpanHoursMinutesSeconds]    Script Date: 7/21/2017 2:09:38 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ToTimeSpanHoursMinutesSeconds]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[ToTimeSpanHoursMinutesSeconds]
GO

/****** Object:  UserDefinedFunction [dbo].[ToTimeSpanHoursMinutesSeconds]    Script Date: 7/21/2017 2:09:38 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ToTimeSpanHoursMinutesSeconds]') AND type IN (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
EXECUTE dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author, Brian Thrapp>
-- Create date: <Create Date, 03/30/2017>
-- Description:	<Description, Convert the difference between two datetimes to hours:minutes:seconds (00:00:00).>
-- =============================================
CREATE FUNCTION [dbo].[ToTimeSpanHoursMinutesSeconds]
(
	@start_dt_tm DATETIME
	,@end_dt_tm  DATETIME
)
RETURNS CHAR(8)
AS
BEGIN

	DECLARE @result CHAR(8)

	SET @result = ''''

	DECLARE @MILLISECONDS_PER_HOUR INT
	SET @MILLISECONDS_PER_HOUR = 3600000
	DECLARE @MILLISECONDS_PER_MINUTE INT
	SET @MILLISECONDS_PER_MINUTE = 60000
	DECLARE @MILLISECONDS_PER_SECOND INT
	SET @MILLISECONDS_PER_SECOND = 1000

	DECLARE @elapsed_ms   INT
	DECLARE @remaining_ms INT
	DECLARE @hours        INT
	DECLARE @minutes      INT
	DECLARE @seconds      INT

	SET @elapsed_ms = DATEDIFF(MILLISECOND, @start_dt_tm, @end_dt_tm);
	SET @hours = @elapsed_ms / @MILLISECONDS_PER_HOUR;
	IF @hours >= 1
	BEGIN
		SET @remaining_ms = @elapsed_ms % @MILLISECONDS_PER_HOUR;
	END
	ELSE
	BEGIN
		SET @remaining_ms = @elapsed_ms;
	END
	SET @minutes = @remaining_ms / @MILLISECONDS_PER_MINUTE;
	IF @minutes >= 1
	BEGIN
		SET @remaining_ms = @elapsed_ms % @MILLISECONDS_PER_MINUTE;
	END
	SET @seconds = COALESCE(@remaining_ms / @MILLISECONDS_PER_SECOND, 0);
	SET @remaining_ms = @elapsed_ms % @MILLISECONDS_PER_SECOND;
	IF @remaining_ms > 0
	BEGIN
		SET @seconds += 1
	END

	DECLARE @elapsed_hours_minutes_seconds VARCHAR(8);

	SET @elapsed_hours_minutes_seconds = RIGHT((''00'' + CONVERT(VARCHAR(2), @hours)),2)
									   + '':'' + RIGHT((''00'' + CONVERT(VARCHAR(2), @minutes)),2)
									   + '':'' + RIGHT((''00'' + CONVERT(VARCHAR(2), @seconds)),2);

	SET @result = @elapsed_hours_minutes_seconds

	RETURN @result

END
' 
END

GO


