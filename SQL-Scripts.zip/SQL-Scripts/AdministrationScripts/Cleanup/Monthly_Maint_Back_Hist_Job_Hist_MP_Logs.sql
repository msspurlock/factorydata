USE [ISDB]
GO

/****** Object:  StoredProcedure [dbo].[Monthly_Maint_Back_Hist_Job_Hist_MP_Logs]    Script Date: 7/11/2017 1:04:59 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Monthly_Maint_Back_Hist_Job_Hist_MP_Logs]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Monthly_Maint_Back_Hist_Job_Hist_MP_Logs]
GO

/****** Object:  StoredProcedure [dbo].[Monthly_Maint_Back_Hist_Job_Hist_MP_Logs]    Script Date: 7/11/2017 1:04:59 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Monthly_Maint_Back_Hist_Job_Hist_MP_Logs]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[Monthly_Maint_Back_Hist_Job_Hist_MP_Logs] AS' 
END
GO

ALTER PROC [dbo].[Monthly_Maint_Back_Hist_Job_Hist_MP_Logs] 

    @oldest_date        DATETIME     = NULL
    ,@no_email          BIT          = 0
    ,@email_recipients  VARCHAR(MAX) = NULL

AS
BEGIN

    SET NOCOUNT ON


    DECLARE @sproc_start_dt_tm DATETIME;
    DECLARE @sproc_end_dt_tm   DATETIME;

    SET @sproc_start_dt_tm = GETDATE();

    SET @oldest_date = COALESCE(@oldest_date, CONVERT(DATETIME, CONVERT(VARCHAR(10), DATEADD(dd, -183, GETDATE()), 101)));


    -------------------------------------------------------------------------------------------------
    -- BEGIN - BACKUP SET CLEANUP
    -------------------------------------------------------------------------------------------------
    DECLARE @bsh_start_dt_tm DATETIME;
    DECLARE @bsh_end_dt_tm   DATETIME;
    DECLARE @bsh_elapsed_ms  INT;

    SET @bsh_start_dt_tm = GETDATE();

    DECLARE @bsh_min_backup_start_date_pre  DATETIME;
    DECLARE @bsh_min_backup_finish_date_pre DATETIME;
    DECLARE @bsh_record_count_pre           INT;

    SELECT 
	   @bsh_min_backup_start_date_pre   = MIN(backup_start_date) 
	   ,@bsh_min_backup_finish_date_pre = MIN(backup_finish_date) 
	   ,@bsh_record_count_pre           = COUNT(*)
    FROM 
	   msdb.dbo.backupset;


    ----To speed up the backup history deletion I created 3 indexes:
    CREATE NONCLUSTERED INDEX [IX_backupset_database_name_backup_set_id]
	   ON msdb.dbo.[backupset] ([database_name])
	   INCLUDE ([backup_set_id]);

    CREATE NONCLUSTERED INDEX [IX_backupset_database_name_media_set_id]
	   ON msdb.dbo.[backupset] ([database_name])
	   INCLUDE ([media_set_id]);

    CREATE NONCLUSTERED INDEX [_ped_backupset_media_set_id]
	   ON msdb.dbo.[backupset] ([media_set_id]);


    DECLARE @dbh_status INT;

    EXEC @dbh_status = msdb.dbo.sp_delete_backuphistory @oldest_date;
    --GO 

    DROP INDEX [IX_backupset_database_name_backup_set_id]
	   ON msdb.dbo.[backupset]
	   WITH
	   (   ONLINE = OFF);

    DROP INDEX [IX_backupset_database_name_media_set_id]
	   ON msdb.dbo.[backupset]
	   WITH
	   (   ONLINE = OFF);

    DROP INDEX [_ped_backupset_media_set_id]
	   ON msdb.dbo.[backupset]
	   WITH
	   (   ONLINE = OFF);
    --GO 


    DECLARE @bsh_min_backup_start_date_post  DATETIME;
    DECLARE @bsh_min_backup_finish_date_post DATETIME;
    DECLARE @bsh_record_count_post           INT;

    SELECT 
	   @bsh_min_backup_start_date_post   = MIN(backup_start_date) 
	   ,@bsh_min_backup_finish_date_post = MIN(backup_finish_date) 
	   ,@bsh_record_count_post           = COUNT(*)
    FROM 
	   msdb.dbo.backupset;


    SET @bsh_end_dt_tm = GETDATE();
    SET @bsh_elapsed_ms = DATEDIFF(MILLISECOND, @bsh_start_dt_tm, @bsh_end_dt_tm);
    -------------------------------------------------------------------------------------------------
    -- END - BACKUP SET CLEANUP
    -------------------------------------------------------------------------------------------------




    -------------------------------------------------------------------------------------------------
    -- BEGIN - JOB HISTORY CLEANUP
    -------------------------------------------------------------------------------------------------
    DECLARE @pjh_start_dt_tm DATETIME;
    DECLARE @pjh_end_dt_tm   DATETIME;
    DECLARE @pjh_elapsed_ms  INT;

    SET @pjh_start_dt_tm = GETDATE();

    DECLARE @pjh_record_count_pre INT;

    --select * from sysjobhistory order by run_date
    SELECT 
	   @pjh_record_count_pre = COUNT(*) 
    FROM 
	   msdb.dbo.sysjobhistory;


    DECLARE @pjh_status INT;

    EXEC @pjh_status = msdb.dbo.sp_purge_jobhistory NULL, NULL, @oldest_date;

    --select * from sysjobhistory
    DECLARE @pjh_record_count_post INT;

    --select * from sysjobhistory order by run_date
    SELECT 
	   @pjh_record_count_post = COUNT(*) 
    FROM 
	   msdb.dbo.sysjobhistory;

    SET @pjh_end_dt_tm = GETDATE();
    SET @pjh_elapsed_ms = DATEDIFF(MILLISECOND, @pjh_start_dt_tm, @pjh_end_dt_tm);
    -------------------------------------------------------------------------------------------------
    -- END - JOB HISTORY CLEANUP
    -------------------------------------------------------------------------------------------------




    -------------------------------------------------------------------------------------------------
    -- BEGIN - MAINT PLAN LOG CLEANUP
    -------------------------------------------------------------------------------------------------
    DECLARE @mpdl_start_dt_tm DATETIME;
    DECLARE @mpdl_end_dt_tm   DATETIME;
    DECLARE @mpdl_elapsed_ms  INT;

    SET @mpdl_start_dt_tm = GETDATE();

    --select * from sysmaintplan_log order by start_time
    --select * from sysmaintplan_logdetail

    DECLARE @mpdl_log_record_count_pre    INT;
    DECLARE @mpdl_detail_record_count_pre INT;

    SELECT 
	   @mpdl_log_record_count_pre = COUNT(*) 
    FROM 
	   msdb.dbo.sysmaintplan_log;

    SELECT 
	   @mpdl_detail_record_count_pre = COUNT(*) 
    FROM 
	   msdb.dbo.sysmaintplan_logdetail;

    DECLARE @mpdl_status INT;

    EXEC @mpdl_status = msdb.dbo.sp_maintplan_delete_log NULL, NULL, @oldest_date;

    --select * from sysmaintplan_log order by start_time
    --select * from sysmaintplan_logdetail

    DECLARE @mpdl_log_record_count_post    INT;
    DECLARE @mpdl_detail_record_count_post INT;

    SELECT 
	   @mpdl_log_record_count_post = COUNT(*) 
    FROM 
	   msdb.dbo.sysmaintplan_log;

    SELECT 
	   @mpdl_detail_record_count_post = COUNT(*) 
    FROM 
	   msdb.dbo.sysmaintplan_logdetail;

    SET @mpdl_end_dt_tm = GETDATE();
    SET @mpdl_elapsed_ms = DATEDIFF(MILLISECOND, @mpdl_start_dt_tm, @mpdl_end_dt_tm);
    -------------------------------------------------------------------------------------------------
    -- END - MAINT PLAN LOG CLEANUP
    -------------------------------------------------------------------------------------------------


    IF @no_email = 0
    BEGIN

	   SET @email_recipients = COALESCE(@email_recipients, 'SQL_MGMT@consumerdirectcare.com')

	   DECLARE @subject     VARCHAR(255)
	   DECLARE @report_html VARCHAR(MAX)

	   DECLARE @overall_status VARCHAR(25)

	   SET @overall_status = CASE 
						    WHEN @dbh_status = 0
						         AND @pjh_status = 0
							    AND @mpdl_status = 0 THEN 'Successful'
						    ELSE 'Failed'
					     END

	   SET @subject = @@SERVERNAME + ' - ' + @overall_status + ' - Monthly Cleanup, Backupset history, <br />Job History, and Maintenance Plan Log'

	   SET @report_html = '<table border="1" cellpadding="5" cellspacing = "0">'
	   SET @report_html = @report_html + '<tr><td class="header">' + @subject + '</td></tr>'
	   SET @report_html = @report_html + '<tr><td class="header"><table border="1" cellpadding="5" cellspacing = "0">'
	   
	   SET @report_html = @report_html + '<tr><td class="header">Status</td><td class="header">Step</td><td class="header">Duration</td><td class="header">Records Removed</td></tr>'
	   
	   DECLARE @step_status VARCHAR(25)
	   DECLARE @step_class  VARCHAR(25)

	   SET @step_status = CASE @dbh_status WHEN 0 THEN 'Successful' ELSE 'Failed' END;
	   SET @step_class  = CASE @dbh_status WHEN 0 THEN 'sodd' ELSE 'fodd' END;
	   SET @report_html = @report_html + '<tr><td class="' + @step_class + '">' + @step_status + '</td>'  -- Status
	   SET @report_html = @report_html + '<td class="' + @step_class + '">Backup Set History Deletions</td>'      -- Step
	   SET @report_html = @report_html + '<td class="' + @step_class + '">' + ISDB.dbo.ToTimeSpanHoursMinutesSeconds(@bsh_start_dt_tm, @bsh_end_dt_tm) + '</td>'      -- Duration
	   SET @report_html = @report_html + '<td class="' + @step_class + '">' + CONVERT(VARCHAR(25), (@bsh_record_count_pre - @bsh_record_count_post)) + '</td></tr>' -- Record Count

	   SET @step_status = CASE @dbh_status WHEN 0 THEN 'Successful' ELSE 'Failed' END;
	   SET @step_class  = CASE @dbh_status WHEN 0 THEN 'seven' ELSE 'feven' END;
	   SET @report_html = @report_html + '<tr><td class="' + @step_class + '">' + @step_status + '</td>'  -- Status
	   SET @report_html = @report_html + '<td class="' + @step_class + '">Job History Deletions</td>'      -- Step
	   SET @report_html = @report_html + '<td class="' + @step_class + '">' + ISDB.dbo.ToTimeSpanHoursMinutesSeconds(@pjh_start_dt_tm, @pjh_end_dt_tm) + '</td>'      -- Duration
	   SET @report_html = @report_html + '<td class="' + @step_class + '">' + CONVERT(VARCHAR(25), (@pjh_record_count_pre - @pjh_record_count_post)) + '</td></tr>' -- Record Count
	   
	   SET @step_status = CASE @dbh_status WHEN 0 THEN 'Successful' ELSE 'Failed' END;
	   SET @step_class  = CASE @dbh_status WHEN 0 THEN 'sodd' ELSE 'fodd' END;
	   SET @report_html = @report_html + '<tr><td class="' + @step_class + '">' + @step_status + '</td>'  -- Status
	   SET @report_html = @report_html + '<td class="' + @step_class + '">Maint. Plan Log Deletions</td>'      -- Step
	   SET @report_html = @report_html + '<td class="' + @step_class + '">' + ISDB.dbo.ToTimeSpanHoursMinutesSeconds(@bsh_start_dt_tm, @bsh_end_dt_tm) + '</td>'      -- Duration
	   SET @report_html = @report_html + '<td class="' + @step_class + '">' + CONVERT(VARCHAR(25), ((@mpdl_log_record_count_pre + @mpdl_detail_record_count_pre) - (@mpdl_log_record_count_post + @mpdl_detail_record_count_post))) + '</td></tr>' -- Record Count
	   
	   SET @report_html = @report_html + '</table>'
	   
	   SET @report_html = @report_html + '</td></tr></table>'
	   SET @report_html = '<style>body{font-family:arial;font-size:10pt;}.header{font-weight:bold;background-color:#dfbf9f;}.sodd{background-color:#ffffff;}.seven{background-color:#f9f2ec;}.fodd{background-color:#ffe6e6;}.feven{background-color:#ffb3b3;}</style>' + @report_html;

	   EXEC msdb.dbo.sp_send_dbmail
				    @profile_name = 'SQLMail',
				    @recipients   = @email_recipients,
				    @subject      = @subject,
				    @body         = @report_html,
				    @body_format  = 'HTML'

    END

    --CHECK SIZES OF TEMPDB FILES!
    --CHECK SIZE OF REPORTSERVERTEMPDB LOG FILE - KEEP IT AT 500 MB


exit_point:


    SET NOCOUNT OFF


END
GO