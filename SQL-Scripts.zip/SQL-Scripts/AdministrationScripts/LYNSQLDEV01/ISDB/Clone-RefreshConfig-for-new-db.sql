
INSERT INTO
	ISDB.dbo.RefreshConfig
(
	DatabaseName
	,DevBackupFilePath
	,ProductionFileShare
	,ProductionBackupFilePath
	,ProdBackupFilename
	,NetworkPath
	,BackupStartDate
	,BackupFinishDate
	,RestoreFilename
	,RecoveryMode
	,LastRestore
	,Skip
)
SELECT
	'CDMAAPP' AS DatabaseName
	,REPLACE(DevBackupFilePath, 'CDIDAPP', 'CDMAAPP') AS DevBackupFilePath
	,REPLACE(ProductionFileShare, 'CDIDAPP', 'CDMAAPP') AS ProductionFileShare
	,REPLACE(ProductionBackupFilePath, 'CDIDAPP', 'CDMAAPP') AS ProductionBackupFilePath
	,NULL AS ProdBackupFilename
	,NULL AS NetworkPath
	,NULL AS BackupStartDate
	,NULL AS BackupFinishDate
	,REPLACE(RestoreFilename, 'CDIDAPP', 'CDMAAPP') AS RestoreFilename
	,'SIMPLE' AS RecoveryMode
	,NULL AS LastRestore
	,1 AS Skip
FROM
	ISDB.dbo.RefreshConfig
WHERE
	DatabaseName = 'CDIDAPP'
