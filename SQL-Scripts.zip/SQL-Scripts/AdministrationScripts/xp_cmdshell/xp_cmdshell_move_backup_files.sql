/*
EXEC xp_cmdshell 'DIR D:\Backups\Files\ZeacomConfig\ZeacomConfig_backup_pre_drop_db_20180213_0940.bak'
EXEC xp_cmdshell 'DIR D:\Backups\Files\ZeacomDefaults\ZeacomDefaults_backup_pre_drop_db_20180213_0943.bak'
EXEC xp_cmdshell 'DIR D:\Backups\Files\ZeacomMedia\ZeacomMedia_backup_pre_drop_db_20180213_0943.bak'
EXEC xp_cmdshell 'DIR D:\Backups\Files\ZeacomSnapshot\ZeacomSnapshot_backup_pre_drop_db_20180213_0943.bak'
EXEC xp_cmdshell 'DIR D:\Backups\Files\ZeacomVoice\ZeacomVoice_backup_pre_drop_db_20180213_0943.bak'
*/

/*
EXEC xp_cmdshell 'move D:\Backups\Files\ZeacomConfig\ZeacomConfig_backup_pre_drop_db_20180213_0940.bak D:\SavedZeacom'

EXEC xp_cmdshell 'move D:\Backups\Files\ZeacomDefaults\ZeacomDefaults_backup_pre_drop_db_20180213_0943.bak D:\SavedZeacom'
EXEC xp_cmdshell 'move D:\Backups\Files\ZeacomMedia\ZeacomMedia_backup_pre_drop_db_20180213_0943.bak D:\SavedZeacom'
EXEC xp_cmdshell 'move D:\Backups\Files\ZeacomSnapshot\ZeacomSnapshot_backup_pre_drop_db_20180213_0943.bak D:\SavedZeacom'
EXEC xp_cmdshell 'move D:\Backups\Files\ZeacomVoice\ZeacomVoice_backup_pre_drop_db_20180213_0943.bak D:\SavedZeacom'
*/

EXEC xp_cmdshell 'DIR x:\MSSQLTEST\Backups\Integration_backup_2018_12_04_08_22.bak'
EXEC xp_cmdshell 'DIR \\server05\Company\MHS'

--EXEC xp_cmdshell 'MKDIR D:\SavedZeacom'
EXEC xp_cmdshell 'COPY x:\MSSQLTEST\Backups\Integration_backup_2018_12_04_08_22.bak \\server05\Company\MHS'


