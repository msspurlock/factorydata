
/*
EXEC xp_cmdshell 'DEL D:\MSSQL\Enghouse\ZeacomConfig.mdf'
EXEC xp_cmdshell 'DEL D:\MSSQL\Enghouse\ZeacomConfig.ldf'

EXEC xp_cmdshell 'DEL D:\MSSQL\Enghouse\ZeacomDefaults.mdf'
EXEC xp_cmdshell 'DEL D:\MSSQL\Enghouse\ZeacomDefaults.ldf'
EXEC xp_cmdshell 'DEL D:\MSSQL\Enghouse\ZeacomMedia.mdf'
EXEC xp_cmdshell 'DEL D:\MSSQL\Enghouse\ZeacomMedia.ldf'
EXEC xp_cmdshell 'DEL D:\MSSQL\Enghouse\ZeacomSnapshot.mdf'
EXEC xp_cmdshell 'DEL D:\MSSQL\Enghouse\ZeacomSnapshot.ldf'
EXEC xp_cmdshell 'DEL D:\MSSQL\Enghouse\ZeacomVoice.mdf'
EXEC xp_cmdshell 'DEL D:\MSSQL\Enghouse\ZeacomVoice.ldf'
*/

/*
-- ACCESS DENIED
EXEC xp_cmdshell 'RMDIR /Q /S D:\MSSQL\Enghouse'
*/

EXEC xp_cmdshell 'DIR D:\Backups\Files\'

EXEC xp_cmdshell 'DIR D:\Backups\Files\ZeacomConfig'

EXEC xp_cmdshell 'RMDIR D:\Backups\Files\ZeacomConfig'

-- DO NOT REMOVE THESE DIRS, THEY ARE USED BY THE EICC INSTANCE FOR LOG SHIPPING
--EXEC xp_cmdshell 'RMDIR-ZZZ /Q /S D:\Backups\Files\ZeacomDefaults'
--EXEC xp_cmdshell 'RMDIR-ZZZ /Q /S D:\Backups\Files\ZeacomMedia'
--EXEC xp_cmdshell 'RMDIR-ZZZ /Q /S D:\Backups\Files\ZeacomSnapshot'
--EXEC xp_cmdshell 'RMDIR-ZZZ /Q /S D:\Backups\Files\ZeacomVoice'

EXEC xp_cmdshell 'DEL /Q D:\Backups\Files\ZeacomConfig\*'
