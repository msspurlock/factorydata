
/*
EXEC xp_cmdshell 'dir H:\MSSQL\Data\Dynamics'
EXEC xp_cmdshell 'dir X:\MSSQL\Backups\Files\CDMAAPP'

EXEC xp_cmdshell 'dir X:\MSSQL\Backups\Files\ReportServer\'

EXEC xp_cmdshell 'dir X:\MSSQL\Backups\Files\ReportServer\'
EXEC xp_cmdshell 'dir X:\MSSQL\Backups\Files\ReportServerTempDB\'
*/

/*
EXEC xp_cmdshell 'dir X:\MSSQL\backups\files'

EXEC xp_cmdshell 'mkdir X:\MSSQL\backups\from_lynsqlc01'
EXEC xp_cmdshell 'dir X:\MSSQL\backups\from_lynsqlc01'
EXEC xp_cmdshell 'mkdir X:\MSSQL\backups\from_lynsqlc01\CCD'
EXEC xp_cmdshell 'mkdir X:\MSSQL\backups\from_lynsqlc01\SLSystem'
*/

/*
EXEC xp_cmdshell 'dir \\solomon_conversion\ExportDir\CCD'

EXEC xp_cmdshell 'dir \\solomon_conversion\ExportDir\SLSystem'


EXEC xp_cmdshell 'copy \\solomon_conversion\ExportDir\CCD\*.* X:\MSSQL\backups\from_lynsqlc01\CCD'

EXEC xp_cmdshell 'copy \\solomon_conversion\ExportDir\SLSystem\*.* X:\MSSQL\backups\from_lynsqlc01\SLSystem'



EXEC xp_cmdshell 'dir H:\MSSQL\Data\DYNAMICS\'
EXEC xp_cmdshell 'dir L:\MSSQL\Logs\DYNAMICS\'
*/

/*LYNSQL01/UTEX*/
EXEC xp_cmdshell 'dir W:\Backups\Files\CDVAAPP\CDVAAPP_backup_2019_01_22_Paused_Payroll.bak'

EXEC xp_cmdshell 'dir \\AZRSQLDEV01\ToAZRSQLDEV'

--EXEC xp_cmdshell 'copy F:\MSSQL\UTEX\Backup\Files\UTEXDB\UTEXDB_backup_2018_08_13_154122_4836880.bak \\LYNSQLDEV01\ManualRefreshSource'

/*
08/13/2018  03:41 PM       758,222,336 UTEXDB_backup_2018_08_13_154122_4836880.bak
*/