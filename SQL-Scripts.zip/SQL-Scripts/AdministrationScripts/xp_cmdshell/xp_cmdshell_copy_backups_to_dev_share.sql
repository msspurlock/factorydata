/*
03/05/2018  03:17 PM         5,341,184 ReportServer_backup_2018_03_05_151500.bak
03/05/2018  03:18 PM           978,944 ReportServerTempDB_backup_2018_03_05_151500.bak
*/
/*
EXEC xp_cmdshell 'dir W:\MSSQL\Backups\Files\PayrollTaxReporting'
EXEC xp_cmdshell 'dir X:\MSSQL\Backups\Files\sugarcrm_db\sugarcrm_db_backup_2018_01_19_113200.bak'

EXEC xp_cmdshell 'dir X:\MSSQL\Backups\Files\CRM_MSCRM\CRM_MSCRM_backup_2018_03_05_130500.bak'
EXEC xp_cmdshell 'dir X:\MSSQL\Backups\Files\CRM_MSCRM\CRM_MSCRM_backup_2018_02_05_*.trn'
EXEC xp_cmdshell 'dir X:\MSSQL\Backups\Files\CRM_MSCRM\CRM_MSCRM_backup_2017_11_21_*.trn'
*/

/*
--EXEC xp_cmdshell 'copy X:\MSSQL\Backups\Files\sugarcrm_db\sugarcrm_db_backup_2018_01_19_113200.bak \\LYNSQLDEV01\CRMUPgradeBackup'

EXEC xp_cmdshell 'copy X:\MSSQL\Backups\Files\ReportServer\ReportServer_backup_2018_03_05_151500.bak \\LYNCRMSQLN01\CRMBackups'
EXEC xp_cmdshell 'copy X:\MSSQL\Backups\Files\ReportServerTempDB\ReportServerTempDB_backup_2018_03_05_151500.bak \\LYNCRMSQLN01\CRMBackups'

EXEC xp_cmdshell 'copy X:\MSSQL\Backups\Files\CRM_MSCRM\CRM_MSCRM_backup_2018_03_05_140501_6300385.trn \\LYNCRMSQLN01\CRMBackups'

--EXEC xp_cmdshell 'copy X:\MSSQL\Backups\Files\CRM_MSCRM\CRM_MSCRM_backup_2017_12_12_*.trn \\LYNSQLDEV01\CRMUPgradeBackup'
--EXEC xp_cmdshell 'copy X:\MSSQL\Backups\Files\CRM_MSCRM\CRM_MSCRM_backup_2017_11_13_080502_1289063.trn \\LYNSQLDEV01\CRMUPgradeBackup'
--EXEC xp_cmdshell 'copy X:\MSSQL\Backups\Files\CRM_MSCRM\CRM_MSCRM_backup_2017_11_13_090501_4471997.trn \\LYNSQLDEV01\CRMUPgradeBackup'

--EXEC xp_cmdshell 'copy W:\MSSQL\Backups\Files\PayrollTaxReporting\PayrollTaxReporting_backup_2018_01_24_200030_8206952.bak \\LYNSQLDEV01\CRMUPgradeBackup'
--EXEC xp_cmdshell 'copy W:\MSSQL\Backups\Files\PayrollTaxReporting\PayrollTaxReporting_backup_2018_01_25_*.trn \\LYNSQLDEV01\CRMUPgradeBackup'
*/
--01/19/2018  11:32 AM     3,912,269,824 sugarcrm_db_backup_2018_01_19_113200.bak
-- EXEC xp_cmdshell 'dir \\LYNSQLDEV01\CRMUPgradeBackup'
-- EXEC xp_cmdshell 'dir \\LYNCRMSQLDEVN01\CRMBackups'
-- EXEC xp_cmdshell 'DIR \\LYNCRMSQLN01\CRMBackups'



