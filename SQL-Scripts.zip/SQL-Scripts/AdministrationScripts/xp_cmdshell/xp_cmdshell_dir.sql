

/*
EXEC xp_cmdshell 'dir \\HQSQLDR01\X$\MSSQL'
EXEC xp_cmdshell 'dir \\LYNSQLC01\XBackups$'
*/


EXEC xp_cmdshell 'dir X:\MSSQL\Backups\Files\CRM_MSCRM\*.bak'


/*
EXEC xp_cmdshell 'dir G:\MSSQL\Data\CRMPREPRODREFRESH_MSCRM.mdf'
EXEC xp_cmdshell 'dir L:\MSSQL\Logs\CRMPREPRODREFRESH_MSCRM_log.ldf'
*/
/*
EXEC xp_cmdshell 'del G:\MSSQL\Data\CRMPREPRODREFRESH_MSCRM.mdf'
EXEC xp_cmdshell 'del L:\MSSQL\Logs\CRMPREPRODREFRESH_MSCRM_log.ldf'
*/

