USE [ISDB]
GO

/****** Object:  Table [dbo].[DeadlockEvents]    Script Date: 6/18/2019 4:07:03 PM ******/
DROP TABLE IF EXISTS [dbo].[DeadlockEvents]
GO

/****** Object:  Table [dbo].[DeadlockEvents]    Script Date: 6/18/2019 4:07:03 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[DeadlockEvents](
	[AlertTime] [DATETIME] NULL,
	[DeadlockGraph] [XML] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


