--Session 1                   
BEGIN TRAN;                
UPDATE ##Employees
SET EmpName = 'Mary'
WHERE EmpId = 1

UPDATE ##Suppliers
SET Fax = N'555-1212'
WHERE SupplierId = 1
--<blocked>

-- ROLLBACK TRAN
