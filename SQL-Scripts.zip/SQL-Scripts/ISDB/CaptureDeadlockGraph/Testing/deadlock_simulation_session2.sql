--Session 2
BEGIN TRAN;

UPDATE ##Suppliers
SET Fax = N'555-1212'
WHERE SupplierId = 1

UPDATE ##Employees
SET Phone = N'555-9999'
WHERE EmpId = 1
--<blocked>

--ROLLBACK TRAN

