USE [msdb]
GO

/****** Object:  Alert [Respond to DEADLOCK_GRAPH]    Script Date: 6/18/2019 3:21:52 PM ******/
IF  EXISTS (SELECT name FROM msdb.dbo.sysalerts WHERE name = N'Respond to DEADLOCK_GRAPH')
EXEC msdb.dbo.sp_delete_alert @name=N'Respond to DEADLOCK_GRAPH'
GO
DECLARE @JobID UNIQUEIDENTIFIER

SELECT @JobID = job_id FROM msdb.dbo.sysjobs
WHERE name = 'Capture_Deadlock_Graph'

DECLARE @server_name sysname = @@SERVERNAME
DECLARE @notification_message_text NVARCHAR(512) = N'DEADLOCK ON ' + CONVERT(NVARCHAR(128), @server_name) + '!!!!!'
/****** Object:  Alert [Respond to DEADLOCK_GRAPH]    Script Date: 6/18/2019 3:21:52 PM ******/
EXEC msdb.dbo.sp_add_alert @name=N'Respond to DEADLOCK_GRAPH', 
		@message_id=0, 
		@severity=0, 
		@enabled=1, 
		@delay_between_responses=0, 
		@include_event_description_in=1, 
		@notification_message=@notification_message_text, 
		@category_name=N'[Uncategorized]', 
		@wmi_namespace=N'\\.\root\Microsoft\SqlServer\ServerEvents\MSSQLSERVER', 
		@wmi_query=N'SELECT * FROM DEADLOCK_GRAPH', 
		@job_id=@JobID --N'e34d0bfc-0ed3-40bc-958f-27ae1add713c'
GO


