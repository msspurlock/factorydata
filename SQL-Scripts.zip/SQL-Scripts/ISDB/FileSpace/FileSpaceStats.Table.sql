USE [ISDB]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FileSpaceStats]') AND type in (N'U'))
ALTER TABLE [dbo].[FileSpaceStats] DROP CONSTRAINT IF EXISTS [DF__FileSpace__Repor__43D61337]
GO

/****** Object:  Table [dbo].[FileSpaceStats]    Script Date: 6/18/2019 3:56:05 PM ******/
DROP TABLE IF EXISTS [dbo].[FileSpaceStats]
GO

/****** Object:  Table [dbo].[FileSpaceStats]    Script Date: 6/18/2019 3:56:05 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[FileSpaceStats](
	[Server_Name] [sysname] NOT NULL,
	[dbName] [sysname] NOT NULL,
	[Flag] [bit] NULL,
	[Fileid] [tinyint] NULL,
	[FileGroup] [sysname] NULL,
	[Total_Space] [decimal](20, 1) NULL,
	[UsedSpace] [decimal](20, 1) NULL,
	[FreeSpace] [decimal](20, 1) NULL,
	[FreePct] [decimal](20, 3) NULL,
	[Name] [varchar](250) NULL,
	[FileName] [sysname] NULL,
	[Report_Date] [datetime] NULL,
	[Recordid] [int] IDENTITY(1,1) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[FileSpaceStats] ADD  DEFAULT (getdate()) FOR [Report_Date]
GO


