USE [ISDB]
GO

/****** Object:  Table [dbo].[dbcc_executions]    Script Date: 8/29/2018 7:44:36 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbcc_executions]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[dbcc_executions](
	[database_name] [nvarchar](128) NOT NULL,
	[batch_id] [uniqueidentifier] NOT NULL,
	[created_dt_tm] [datetime] NOT NULL,
	[status] [tinyint] NOT NULL,
	[started_dt_tm] [datetime] NULL,
	[finished_dt_tm] [datetime] NULL,
 CONSTRAINT [PK_dbcc_executions] PRIMARY KEY CLUSTERED 
(
	[database_name] ASC,
	[batch_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[dbcc_history]    Script Date: 8/29/2018 7:44:36 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbcc_history]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[dbcc_history](
	[Error] [int] NULL,
	[Level] [int] NULL,
	[State] [int] NULL,
	[MessageText] [varchar](7000) NULL,
	[RepairLevel] [int] NULL,
	[Status] [int] NULL,
	[DbId] [int] NULL,
	[DbFragId] [int] NULL,
	[ObjectId] [int] NULL,
	[IndexId] [int] NULL,
	[PartitionID] [int] NULL,
	[AllocUnitID] [int] NULL,
	[RidDbId] [int] NULL,
	[RidPruId] [int] NULL,
	[File] [int] NULL,
	[Page] [int] NULL,
	[Slot] [int] NULL,
	[RefDbId] [int] NULL,
	[RefPruId] [int] NULL,
	[RefFile] [int] NULL,
	[RefPage] [int] NULL,
	[RefSlot] [int] NULL,
	[Allocation] [int] NULL,
	[TimeStamp] [datetime] NULL
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[IndexRebuilds]    Script Date: 8/29/2018 7:44:36 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IndexRebuilds]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[IndexRebuilds](
	[Dbase] [nvarchar](128) NULL,
	[oid] [int] NULL,
	[schema] [nvarchar](128) NULL,
	[table] [sysname] NOT NULL,
	[index] [sysname] NULL,
	[indid] [int] NOT NULL,
	[partitionScheme] [int] NULL,
	[partition] [int] NULL,
	[page_count] [bigint] NULL,
	[avg_fragmentation_in_percent] [float] NULL,
	[avg_page_space_used_in_percent] [float] NULL,
	[type] [tinyint] NOT NULL,
	[RebuildCmd] [nvarchar](200) NULL,
	[RunDate] [smalldatetime] NULL,
	[RecID] [int] IDENTITY(1,1) NOT NULL
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[sql_compatibility_levels]    Script Date: 8/29/2018 7:44:36 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[sql_compatibility_levels]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[sql_compatibility_levels](
	[compatibility_level] [tinyint] NOT NULL,
	[sql_version] [varchar](10) NOT NULL,
 CONSTRAINT [PK_sql_compatibility_levels] PRIMARY KEY CLUSTERED 
(
	[compatibility_level] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_dbcc_history_TimeStamp]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dbcc_history] ADD  CONSTRAINT [DF_dbcc_history_TimeStamp]  DEFAULT (getdate()) FOR [TimeStamp]
END
GO
/****** Object:  StoredProcedure [dbo].[usp_CheckDBIntegrity]    Script Date: 8/29/2018 7:44:36 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_CheckDBIntegrity]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[usp_CheckDBIntegrity] AS' 
END
GO


ALTER PROC [dbo].[usp_CheckDBIntegrity] 

    @database_name     SYSNAME      = NULL
    ,@no_email         BIT          = 1
    ,@email_recipients VARCHAR(MAX) = ''

AS
BEGIN

    SET NOCOUNT ON


    DECLARE @STATUS_ID_QUEUED TINYINT
    SET @STATUS_ID_QUEUED = 1
    DECLARE @STATUS_ID_PROCESSING TINYINT
    SET @STATUS_ID_PROCESSING = 2
    DECLARE @STATUS_ID_COMPLETED TINYINT
    SET @STATUS_ID_COMPLETED = 3
    DECLARE @STATUS_ID_ERROR TINYINT
    SET @STATUS_ID_ERROR = 4


    DECLARE @like_clause VARCHAR(500)

    SET @no_email         = COALESCE(@no_email, 0)
    SET @email_recipients = COALESCE(@email_recipients, '')

     IF @database_name IS NULL -- Run against all databases
     BEGIN

	   TRUNCATE TABLE dbcc_history;

	   DECLARE @batch_id UNIQUEIDENTIFIER;

	   SET @batch_id = NEWID();


	   INSERT INTO
		  ISDB.dbo.dbcc_executions
	   (
		  [database_name]
		  ,[batch_id]
		  ,[created_dt_tm]
		  ,[status]
		  ,[started_dt_tm]
		  ,[finished_dt_tm]
	   )
	   SELECT --TOP 3
		  [name] AS [database_name]
		  ,@batch_id
		  ,GETDATE()
		  ,@STATUS_ID_QUEUED
		  ,NULL
		  ,NULL
	   FROM
		  sys.databases db
	   WHERE
		  [name] NOT IN ( 'tempdb' ) --'master', 'model', 'msdb', 
		  AND db.state_desc = 'ONLINE'
		  AND source_database_id IS NULL -- REAL DBS ONLY (Not Snapshots)
		  AND is_read_only  = 0;

	   DECLARE @previous_database_name SYSNAME

	   SELECT TOP 1
		  @database_name = e.[database_name]
	   FROM
		  ISDB.dbo.dbcc_executions AS e
	   WHERE
		  e.batch_id     = @batch_id
		  AND e.[status] = @STATUS_ID_QUEUED
	   ORDER BY
		  e.[database_name] ASC


        WHILE @database_name IS NOT NULL
        BEGIN

		  DECLARE @batch_sql   NVARCHAR(4000)
		  DECLARE @parameters  NVARCHAR(4000)

		  SET @parameters = '@vc_db_name SYSNAME, @batch_id UNIQUEIDENTIFIER'

		  SET @batch_sql = N'EXEC ISDB.dbo.usp_DBCCCheckDB @vc_db_name, @batch_id'

		  BEGIN TRY

    			 EXEC sys.sp_executesql @batch_sql, @parameters, @vc_db_name = @database_name, @batch_id = @batch_id

		  END TRY
		  BEGIN CATCH
			 SET @batch_sql = ''
		  END CATCH

		  SET @previous_database_name = @database_name
		  SET @database_name          = NULL

		  SELECT TOP 1
			 @database_name = e.[database_name]
		  FROM
			 ISDB.dbo.dbcc_executions AS e
		  WHERE
			 e.batch_id            = @batch_id
			 AND e.[status]        = @STATUS_ID_QUEUED
			 AND e.[database_name] > @previous_database_name
		  ORDER BY
			 e.[database_name] ASC

	   END;  -- end while no database selected

     END;  -- end while batch mode
         ELSE -- run against a specified database (ie: usp_CheckDBIntegrity 'DB Name Here'
	BEGIN

	   --DECLARE @like_clause VARCHAR(500)

	   --SET @database_name = 'CDNVAPP'

        DECLARE @command_sql NVARCHAR(4000)
	   SET @command_sql = N'DBCC CHECKDB(''' + @database_name + ''') WITH TABLERESULTS'

	   SET @like_clause = '%CHECKDB %' + @database_name + '%'
	   DELETE FROM isdb.dbo.dbcc_history WHERE MessageText LIKE @like_clause

	    INSERT INTO dbcc_history
	    ([Error],
		[Level],
		[State],
		[MessageText],
		[RepairLevel],
		[Status],
		[DbId],
		[DbFragId],
		[ObjectId],
		[IndexId],
		[PartitionID],
		[AllocUnitID],
		[RidDbId],
		[RidPruId],
		[File],
		[Page],
		[Slot],
		[RefDbId],
		[RefPruId],
		[RefFile],
		[RefPage],
		[RefSlot],
		[Allocation]
	    )
         EXEC sys.sp_executesql @command_sql;
	    --EXEC ('DBCC CHECKDB(''' + @database_name + ''') WITH TABLERESULTS');
    END


    IF @no_email = 0
    BEGIN

	   DECLARE @dbcc_history_data TABLE
	   (
		  [database_name]      SYSNAME      NOT NULL,
		  [allocation_errors]  INT          NOT NULL,
		  [consistency_errors] INT          NOT NULL,
		  [message_text]       VARCHAR(MAX) NOT NULL,
		  [timestamp]          DATETIME     NOT NULL
	   )

	   INSERT INTO
		  @dbcc_history_data
	   (
		  [database_name],
		  [allocation_errors],
		  [consistency_errors],
		  [message_text],
		  [timestamp]
	   )
	   SELECT
		  COALESCE(db.[name], cd.[db_name], '') AS [database_name],
		  COALESCE(SUBSTRING(cd.allocation_errors, 0, PATINDEX('%[^0-9]%', cd.allocation_errors)), '') AS [allocation_errors],
		  COALESCE(SUBSTRING(cd.consistency_errors, 0, PATINDEX('%[^0-9]%', cd.consistency_errors)), '') AS [consistency_errors],
		  COALESCE(cd.MessageText, 'DBCC RESULTS NOT FOUND') AS [message_text],
		  COALESCE(CONVERT(VARCHAR(25), cd.[TimeStamp]), '') AS [timestamp]
	   FROM
	   (
		  SELECT
			 REPLACE(REPLACE(REPLACE(SUBSTRING(dh.MessageText, PATINDEX('% database %', dh.MessageText), 999), ' database ', ''), '''', ''), '.', '') AS [db_name],
			 LTRIM(RTRIM(REPLACE(SUBSTRING(dh.MessageText, PATINDEX('% found % allocation errors %', dh.MessageText), PATINDEX('% allocation errors %', dh.MessageText)), ' found ', ''))) AS [allocation_errors],
			 LTRIM(RTRIM(REPLACE(SUBSTRING(dh.MessageText, PATINDEX('% and % consistency errors %', dh.MessageText), PATINDEX('% consistency errors %', dh.MessageText) - PATINDEX('% allocation errors %', dh.MessageText)), ' and ', ''))) AS [consistency_errors],
			 dh.MessageText,
			 dh.[TimeStamp]
		  FROM
			 ISDB.dbo.dbcc_history AS dh
		  WHERE
			 dh.MessageText LIKE 'CHECKDB %'
	   ) AS cd
	   LEFT OUTER JOIN
		  sys.databases AS db WITH (NOLOCK)
	   ON
		  cd.[db_name] = db.[name]


	   DECLARE @summary_xml XML

	   SELECT
		  @summary_xml = 
	   (
		  SELECT
			 *
		  FROM
		  (
			 SELECT
				'header' AS "td1/@class",
				'Server Name' AS "td1",
				'header' AS "td2/@class",
				'Database{*LB*}Count' AS "td2",
				'header' AS "td3/@class",
				'CheckDB{*LB*}Count' AS "td3",
				'header' AS "td4/@class",
				'Total{*LB*}Allocation{*LB*}Errors' AS "td4",
				'header' AS "td5/@class",
				'Total{*LB*}Consistency{*LB*}Errors' AS "td5",
				'header' AS "td6/@class",
				'Time Stamp' AS "td6"

			 UNION ALL

			 SELECT
				'odd_row' AS "td1/@class",
				@@SERVERNAME AS "td1",
				'odd_row' AS "td2/@class",
				CONVERT(VARCHAR(25), COUNT(*)) AS "td2",
				'odd_row' AS "td3/@class",
				CONVERT(VARCHAR(25), 
				    SUM(CASE
						  WHEN message_text LIKE '%CHECKDB%' THEN 1
						  ELSE 0
					   END)) AS "td3",
				'odd_row' AS "td4/@class",
				CONVERT(VARCHAR(25), SUM(allocation_errors)) AS "td4",
				'odd_row' AS "td5/@class",
				CONVERT(VARCHAR(25), SUM(consistency_errors)) AS "td5",
				'odd_row' AS "td6/@class",
				CONVERT(VARCHAR(25), MAX(timestamp)) AS "td6"
			 FROM
				@dbcc_history_data
		  ) AS table_data
		  FOR XML PATH('tr'), ELEMENTS, ROOT('table')
	   )

	   DECLARE @report_xml XML

	   SELECT
		  @report_xml = 
	   (
		  SELECT
			 *
		  FROM
		  (
			 SELECT
				'header' AS "td1/@class",
				'Database Name' AS "td1",
				'header' AS "td2/@class",
				'Allocation{*LB*}Errors' AS "td2",
				'header' AS "td3/@class",
				'Consistency{*LB*}Errors' AS "td3",
				'header' AS "td4/@class",
				'Message Text' AS "td4",
				'header' AS "td5/@class",
				'Time Stamp' AS "td5"

			 UNION ALL

			 SELECT
				CASE WHEN is_odd = 1 THEN 'odd_row' ELSE 'even_row' END AS "td1/@class",
				td1 AS "td1",
				CASE WHEN is_odd = 1 THEN 'odd_row' ELSE 'even_row' END AS "td2/@class",
				td2 AS "td2",
				CASE WHEN is_odd = 1 THEN 'odd_row' ELSE 'even_row' END AS "td3/@class",
				td3 AS "td3",
				CASE WHEN is_odd = 1 THEN 'odd_row' ELSE 'even_row' END AS "td4/@class",
				td4 AS "td4",
				CASE WHEN is_odd = 1 THEN 'odd_row' ELSE 'even_row' END AS "td5/@class",
				td5 AS "td5"
			 FROM
			 (
				SELECT
				    td1,
				    CONVERT(VARCHAR(25), td2) AS td2,
				    CONVERT(VARCHAR(25), td3) AS td3,
				    td4,
				    CONVERT(VARCHAR(25), td5) AS td5,
				    (ROW_NUMBER() OVER (ORDER BY tr.td2 DESC, tr.td3 DESC, tr.td1 ASC) % 2) AS is_odd
				FROM
				(
				    SELECT
					   [database_name]      AS td1,
					   [allocation_errors]  AS td2,
					   [consistency_errors] AS td3,
					   [message_text]       AS td4,
					   [timestamp]          AS td5
				    FROM
					   @dbcc_history_data
				) AS tr
			 ) AS dta
		  ) AS table_data
		  ORDER BY
			 td2 DESC,
			 td3 DESC,
			 td1 ASC
		  FOR XML PATH('tr'), ELEMENTS, ROOT('table')
	   )


	   DECLARE @summary_html VARCHAR(MAX)
	   SELECT @summary_html = CONVERT(VARCHAR(MAX), @summary_xml);
	   SELECT @summary_html = REPLACE(@summary_html, '<table>', '<table border="1" cellpadding="5" cellspacing="0">');
	   SELECT @summary_html = REPLACE(@summary_html, 'td1', 'td');
	   SELECT @summary_html = REPLACE(@summary_html, 'td2', 'td');
	   SELECT @summary_html = REPLACE(@summary_html, 'td3', 'td');
	   SELECT @summary_html = REPLACE(@summary_html, 'td4', 'td');
	   SELECT @summary_html = REPLACE(@summary_html, 'td5', 'td');
	   SELECT @summary_html = REPLACE(@summary_html, 'td6', 'td');
	   SELECT @summary_html = REPLACE(@summary_html, '{*LB*}', '<br />');
	   SELECT @summary_html = '<table border="0" cellpadding="5" cellspacing="0"><tr><td class="header">DBCC Results - Executive Summary:</td></tr><tr><td class="header">' + @summary_html + '</td></tr></table>';
	   SELECT @summary_html = '<style>body{color:#12240f;font:arial;font-size:9pt;}.header{background-color:#74c167;font-weight:bold;vertical-align:bottom;}.odd_row{background-color:#eff8ed;}.even_row{background-color:#addaa4;}</style>' + @summary_html


	   DECLARE @report_html VARCHAR(MAX)
	   SELECT @report_html = CONVERT(VARCHAR(MAX), @report_xml)
	   SELECT @report_html = REPLACE(@report_html, '<table>', '<table border="1" cellpadding="5" cellspacing="0">');
	   SELECT @report_html = REPLACE(@report_html, 'td1', 'td');
	   SELECT @report_html = REPLACE(@report_html, 'td2', 'td');
	   SELECT @report_html = REPLACE(@report_html, 'td3', 'td');
	   SELECT @report_html = REPLACE(@report_html, 'td4', 'td');
	   SELECT @report_html = REPLACE(@report_html, 'td5', 'td');
	   SELECT @report_html = REPLACE(@report_html, 'td6', 'td');
	   SELECT @report_html = REPLACE(@report_html, '{*LB*}', '<br />');
	   SELECT @report_html = '<table border="0" cellpadding="5" cellspacing="0"><tr><td class="header">DBCC Results: ' + @@SERVERNAME + '</td></tr><tr><td class="header">' + @report_html + '</td></tr></table>';
	   --SELECT @report_html = '<style>body{color:#12240f;font:arial;font-size:9pt;}div{clear:both;}.header{background-color:#74c167;font-weight:bold;vertical-align:bottom;}.odd_row{background-color:#eff8ed;}.even_row{background-color:#addaa4;}</style>' + @report_html

	   SELECT @report_html = @summary_html + '<br /><br />' + @report_html

	   DECLARE @subject VARCHAR(100)

	   SET @subject = ('DBCC Results: ' + @@SERVERNAME)

	   IF COALESCE(@email_recipients, '') = ''
	   BEGIN
		  SET @email_recipients = 'SQL_MGMT@consumerdirectcare.com'
	   END

	   EXEC msdb.dbo.sp_send_dbmail
				    @profile_name = 'SQLMail',
				    @recipients   = @email_recipients,
				    @subject      = @subject,
				    @body         = @report_html,
				    @body_format  = 'HTML'

    END  -- END IF @no_email = 0

    SET NOCOUNT OFF

END
GO
/****** Object:  StoredProcedure [dbo].[usp_DBCCCheckDB]    Script Date: 8/29/2018 7:44:36 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_DBCCCheckDB]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[usp_DBCCCheckDB] AS' 
END
GO

ALTER PROC [dbo].[usp_DBCCCheckDB] 

    @database_name     SYSNAME          = ''
    ,@batch_id         UNIQUEIDENTIFIER = NULL

AS
BEGIN

    SET NOCOUNT ON


    DECLARE @STATUS_ID_QUEUED TINYINT
    SET @STATUS_ID_QUEUED = 1
    DECLARE @STATUS_ID_PROCESSING TINYINT
    SET @STATUS_ID_PROCESSING = 2
    DECLARE @STATUS_ID_COMPLETED TINYINT
    SET @STATUS_ID_COMPLETED = 3
    DECLARE @STATUS_ID_ERROR TINYINT
    SET @STATUS_ID_ERROR = 4


    IF LTRIM(RTRIM(COALESCE(@database_name, ''))) = ''
    BEGIN
	   RETURN -1
    END

    DECLARE @error INT
    
    SET @error = 0

    IF @batch_id IS NOT NULL
    BEGIN

	   BEGIN TRY

		  UPDATE
			 ISDB.dbo.dbcc_executions
		  SET
			 [status]       = @STATUS_ID_PROCESSING
			 ,started_dt_tm = GETDATE()
		  WHERE
			 [database_name] = @database_name
			 AND batch_id    = @batch_id

	   END TRY
	   BEGIN CATCH
		  SET @error = 1
		  GOTO exit_point
	   END CATCH

    END

    BEGIN TRY

	   INSERT INTO ISDB.dbo.dbcc_history
	   ([Error],
	   [Level],
	   [State],
	   [MessageText],
	   [RepairLevel],
	   [Status],
	   [DbId],
	   [DbFragId],
	   [ObjectId],
	   [IndexId],
	   [PartitionID],
	   [AllocUnitID],
	   [RidDbId],
	   [RidPruId],
	   [File],
	   [Page],
	   [Slot],
	   [RefDbId],
	   [RefPruId],
	   [RefFile],
	   [RefPage],
	   [RefSlot],
	   [Allocation]
	   )
	   EXECUTE('DBCC CHECKDB(''' + @database_name + ''') WITH TABLERESULTS')

    END TRY
    BEGIN CATCH
	   SET @error = 1
	   GOTO exit_point
    END CATCH



exit_point:

    IF @batch_id IS NOT NULL
    BEGIN

	   BEGIN TRY

		  UPDATE
			 ISDB.dbo.dbcc_executions
		  SET
			 [status]        = CASE WHEN @error = 1 THEN @STATUS_ID_ERROR WHEN @error = 0 THEN @STATUS_ID_COMPLETED ELSE 255 END
			 ,finished_dt_tm = GETDATE()
		  WHERE
			 [database_name] = @database_name
			 AND batch_id    = @batch_id

	   END TRY
	   BEGIN CATCH
		  SET @error = 2
	   END CATCH

    END

    SET NOCOUNT OFF

END
GO
USE [master]
GO
ALTER DATABASE [ISDB] SET  READ_WRITE 
GO
