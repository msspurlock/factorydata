USE [msdb]
GO


SELECT ls.primary_server,ls.primary_database,
DATEDIFF(mi,lms.last_restored_date,getdate()) as time_since_last_restore,
lms.last_copied_date,lms.last_copied_file,lms.last_restored_date,
lms.last_restored_file,
lsd.disconnect_users,ls.backup_source_directory,
ls.backup_destination_directory,ls.monitor_server
from
msdb.dbo.log_shipping_secondary ls
join
msdb.dbo.log_shipping_secondary_databases lsd
on lsd.secondary_id=ls.secondary_id
join
msdb.dbo.log_shipping_monitor_secondary lms
on lms.secondary_id=lsd.secondary_id