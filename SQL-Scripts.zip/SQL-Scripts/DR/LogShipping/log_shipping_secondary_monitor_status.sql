SELECT
    d.secondary_server
    ,d.secondary_database
    ,d.last_restored_date
    ,d.last_copied_date
	,*
FROM
	msdb.dbo.log_shipping_monitor_secondary AS d
