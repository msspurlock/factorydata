USE [msdb]
GO

SELECT primary_server,primary_database,
DATEDIFF(mi,last_backup_date,getdate()) as time_since_last_backup,
last_backup_date,last_backup_file from [dbo].[log_shipping_monitor_primary]