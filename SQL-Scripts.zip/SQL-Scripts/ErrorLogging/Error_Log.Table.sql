USE [Integration]
GO

/****** Object:  Table [dbo].[Error_Log]    Script Date: 5/15/2019 10:57:50 AM ******/
DROP TABLE IF EXISTS [dbo].[Error_Log]
GO

/****** Object:  Table [dbo].[Error_Log]    Script Date: 5/15/2019 10:57:50 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Error_Log](
	[error_log_id] [INT] IDENTITY(1,1) NOT NULL,
	[parameters] [VARCHAR](1000) NOT NULL,
	[label] [VARCHAR](50) NOT NULL,
	[error_number] [INT] NOT NULL,
	[error_severity] [INT] NOT NULL,
	[error_state] [INT] NOT NULL,
	[error_procedure] [NVARCHAR](128) NOT NULL,
	[error_line] [INT] NOT NULL,
	[error_message] [NVARCHAR](4000) NOT NULL,
	[created_dt_tm] [SMALLDATETIME] NOT NULL,
 CONSTRAINT [PK_Error_Log] PRIMARY KEY CLUSTERED 
(
	[error_log_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO


