USE [Integration]
GO

/****** Object:  StoredProcedure [dbo].[Error_Log_Cleanup]    Script Date: 5/15/2019 10:58:56 AM ******/
DROP PROCEDURE IF EXISTS [dbo].[Error_Log_Cleanup]
GO

/****** Object:  StoredProcedure [dbo].[Error_Log_Cleanup]    Script Date: 5/15/2019 10:58:56 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROC [dbo].[Error_Log_Cleanup] 

AS
BEGIN

    SET NOCOUNT ON

	DECLARE @out_error_id      INT = 0
	DECLARE @out_error_messge  VARCHAR(MAX) = ''

	DECLARE @CRLF VARCHAR(2) = CHAR(13) + CHAR(10);
	DECLARE @parameters VARCHAR(1000)
	SET @parameters = '' + @CRLF


	DECLARE @label VARCHAR(50)

	DECLARE @two_weeks_ago SMALLDATETIME

	BEGIN TRY

		SET @two_weeks_ago = DATEADD(DAY, -90, CONVERT(SMALLDATETIME, CONVERT(DATE, GETDATE())))

		DELETE FROM dbo.Error_Log
		WHERE created_dt_tm < @two_weeks_ago

	END TRY
	BEGIN CATCH
		EXEC [dbo].[Error_Log_Try_Catch_Error_Information_w_Return] @parameters, @label, @out_error_id OUTPUT, @out_error_messge OUTPUT
	END CATCH


exit_point:


    SET NOCOUNT OFF


END
GO


