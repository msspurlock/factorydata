USE [Integration]
GO

/****** Object:  StoredProcedure [dbo].[Error_Log_Try_Catch_Error_Information_w_Return]    Script Date: 5/15/2019 11:00:53 AM ******/
DROP PROCEDURE IF EXISTS [dbo].[Error_Log_Try_Catch_Error_Information_w_Return]
GO

/****** Object:  StoredProcedure [dbo].[Error_Log_Try_Catch_Error_Information_w_Return]    Script Date: 5/15/2019 11:00:53 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[Error_Log_Try_Catch_Error_Information_w_Return]

    @parameters         VARCHAR(1000),
    @label              VARCHAR(50),
	@out_error_id       INT = 0            OUTPUT,
    @out_error_message  VARCHAR(MAX) = ''  OUTPUT

AS
BEGIN


    SET NOCOUNT ON

    DECLARE @error_number     INT
    DECLARE @error_severity   INT
    DECLARE @error_state      INT
    DECLARE @error_procedure  NVARCHAR(128)
    DECLARE @error_line       INT
    DECLARE @error_message    NVARCHAR(4000)
    DECLARE @created_dt_tm    SMALLDATETIME

    SET @out_error_message = ''
	SET @out_error_id      = 0

    SELECT
        @error_number     = ERROR_NUMBER(),
        @error_severity   = ERROR_SEVERITY(),
        @error_state      = ERROR_STATE(),
        @error_procedure  = ERROR_PROCEDURE(),
        @error_line       = ERROR_LINE(),
        @error_message    = ERROR_MESSAGE(),
        @created_dt_tm    = GETDATE()


    SET @out_error_message = 'Error in procedure ' + ISNULL(@error_procedure, 'NULL')
                           + ', line ' + CONVERT(VARCHAR(25), ISNULL(@error_line, 0))
                           + ', label ' + ISNULL(@label, 'NULL')
                           + '.  Error Message:  ' + ISNULL(@error_message, 'NULL')

	--PRINT '@out_error_message = ' + @out_error_message

    INSERT INTO
	  [dbo].[Error_Log]
    (
	   --[error_log_id]
	   [parameters]
	   ,[label]
	   ,[error_number]
	   ,[error_severity]
	   ,[error_state]
	   ,[error_procedure]
	   ,[error_line]
	   ,[error_message]
	   ,[created_dt_tm]
    )
    VALUES
    (
	   ISNULL(@parameters, 'NULL'),
	   ISNULL(@label, 'NULL'),
	   ISNULL(@error_number, 0),
	   ISNULL(@error_severity, 0),
	   ISNULL(@error_state, 0),
	   ISNULL(@error_procedure, 'NULL'),
	   ISNULL(@error_line, 0),
	   ISNULL(@error_message, 'NULL'),
	   ISNULL(@created_dt_tm, '1/1/1900')
    )

	SELECT @out_error_id = SCOPE_IDENTITY()


END  -- END SPROC
GO


